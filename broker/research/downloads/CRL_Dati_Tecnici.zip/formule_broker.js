function brokerBook(v,p,month,isCrl){
 const commission=p.bCommission/1e6*(v.nominal+v.extra_comm/20e-6*p.bExit/100);
 const spread=p.bSpread*v.pip_basis;
 const retainedFunding=p.bFunding/100*v.notional_years;
 const additional=isCrl?p.bExtra*month:0;
 const loading=isCrl?v.Q*p.bProvider/100:0;
 const a={commission,service:v.service,spread,funding:retainedFunding,
  trading:0,premium:0,payout:0,ops:-v.ops,licence:-v.licence,fixed:-v.fixed,execution:-v.execution,provider:-loading,additional:-additional};
 // B-book already includes all original customer cash flows. Remove original fees
 // before inserting new fees to avoid double counting. Decomposition remains explicit.
 const b={commission,service:v.service,spread,funding:v.fund,
  trading:-v.net-v.comm-v.service-v.fund-v.Q,premium:v.Q,payout:0,
  ops:-v.ops,licence:-v.licence,fixed:-v.fixed,execution:0,provider:0,additional:-additional};
 const out={};for(const k of Object.keys(a))out[k]=(1-p.share)*a[k]+p.share*b[k];
 out.margin=Object.values(out).reduce((x,y)=>x+y,0);
 // Revenue here deliberately excludes market counterparty result and Q.
 out.fee_revenue=out.commission+out.service+out.spread+out.funding;
 return out;
}
