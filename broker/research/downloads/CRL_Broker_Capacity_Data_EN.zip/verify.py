from pathlib import Path
import numpy as np,json,hashlib,ast
P=Path(__file__).resolve().parent;R=P.parent
S=json.loads((P/'summary.json').read_text(encoding='utf8'));rr=json.loads((P/'monthly_detail.json').read_text(encoding='utf8'))
for name,h in json.loads((P/'source_hashes.json').read_text()).items():assert hashlib.sha256((R/name).read_bytes()).hexdigest()==h
tree=ast.parse((P/'analyze.py').read_text(encoding='utf8'));ns={'np':np}
exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in ['aggregate','rolling','rolling_peaks_by_month']],type_ignores=[]),'rolling','exec'),ns)
# Exact boundary, identical timestamps, no future leakage into monthly output.
t=np.array([0,100,100,200,1000]);v=np.array([2.,3.,5.,7.,100.])
assert ns['rolling'](t,v,100)[0]==100
assert np.array_equal(ns['rolling_peaks_by_month'](t,v,100,np.array([0,100,200,999,1000])),[2,8,8,8,100])
for r in rr:
 assert r['cash_proxy_reserve']>=0 and r['cash_proxy_drawdown']>=r['cash_proxy_reserve']-1e-6
 assert r['gain_payments_24h']>=r['gain_payments_1h']-1e-6
assert S['checks']['monthly_replay_max_error']<1e-6
out=dict(status='PASS',source_hashes_unchanged=True,rolling_boundaries_and_no_future_leakage=True,risk_bounds=True,monthly_reconciliations=len(rr),independent_review=False)
(P/'verification.json').write_text(json.dumps(out,indent=2));print(json.dumps(out))
