ENGLISH TECHNICAL PACKAGE

All reader-facing documentation and descriptive data have been translated. Technical filenames, schema keys, source paths and identifiers are retained for compatibility. Numerical data and formulas are unchanged.

The source code is supplied for reproducibility in the original project layout; this ZIP does not contain every historical input. Original UI-verification string fixtures intentionally retain the exact strings expected by the original Italian UI. They are test data, not untranslated documentation.

Historical checks describe the original calculation. Translation validation is separate and does not constitute a new independent quantitative review. Historical source hashes refer to original inputs and remain unchanged. Original package manifests are retained under provenance/. sha256.json verifies the files in this English package; TRANSLATION_EN.json records source and translated hashes.
