const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const P=__dirname,D=path.join(P,'../CRL_MONTHLY_CLIENT_BROKER_20261002'),els={};
const document={getElementById(id){return els[id]??={value:id==='capBook'?'a':'0',innerHTML:'',textContent:'',events:{},addEventListener(n,f){this.events[n]=f;}};}};
const ctx={document,window:{}};vm.createContext(ctx);vm.runInContext(fs.readFileSync(path.join(D,'capacity_data.js'),'utf8'),ctx);vm.runInContext(fs.readFileSync(path.join(D,'capacity.js'),'utf8'),ctx);
let count=0;
const s=JSON.parse(fs.readFileSync(path.join(P,'summary.json'),'utf8'));
const fn=ctx.window.CRL_CAPACITY_CALCULATE;
const p={cac:1000,support:20,loading:.01,capital:2000,rate:.1,migration:.5,transition:100};
for(const book of ['a','hybrid','b']){
 const r=s.final.find(x=>x.book===book&&x.product==='crl'&&x.stress==='latency5_slip05'),t=s.final.find(x=>x.book===book&&x.product==='std'&&x.stress==='latency5_slip05');
 const q=fn(r,t,p),external={a:1,hybrid:.9,b:0}[book];
 const costs=480+400+external*.01*r.Q;
 assert(Math.abs(q.margin-(r.margin-1000-costs))<1e-8);
 assert(Math.abs(q.incremental-(r.margin-.5*t.margin-costs-500-50))<1e-8);
 const migrated=fn(r,t,{cac:9999,support:0,loading:0,capital:0,rate:0,migration:1,transition:0});
 assert(Math.abs(migrated.incremental-(r.margin-t.margin))<1e-8);
 for(const C of [0,1000])for(const F of [0,20])for(const load of [0,1])for(const mig of [0,50,100]){
  els.capBook.value=book;els.capCAC.value=String(C);els.capService.value=String(F);els.capLoading.value=String(load);els.capMigration.value=String(mig);els.capBook.events.change();
  assert((els.capMonths.innerHTML.match(/<tr>/g)||[]).length===25);
  assert(!/NaN|undefined|Infinity/.test(els.capMonths.innerHTML));count++;
 }
}
const out={status:'PASS',cost_loading_capital_and_migration_oracles:true,rendered_views:count,monthly_rows:24};
fs.writeFileSync(path.join(P,'ui_checks.json'),JSON.stringify(out,null,2));console.log(JSON.stringify(out));
