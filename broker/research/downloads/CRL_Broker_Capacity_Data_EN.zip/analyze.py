from pathlib import Path
import numpy as np,json,hashlib
P=Path(__file__).resolve().parent;R=P.parent;D=R/'CRL_MONTHLY_CLIENT_BROKER_20261002';E=R/'CRL_BROKER_REVIEW_CLAUDE/results/events';T=R/'CRL_5_5_VALIDATION_20261002_CLAUDE/results'
def read(p):return json.loads(p.read_text(encoding='utf8'))
def write(n,x):(P/n).write_text(json.dumps(x,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf8')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
hashes={};checks=dict(monthly_replay_max_error=0.,bbook_identity_max_error=0.,rolling_oracle_max_error=0.)
def track(p):hashes[str(p.relative_to(R))]=digest(p)
track(P/'protocol.json');track(D/'broker_data.json')
ref=read(D/'broker_data.json')['rows'];lookup={(r['window'],r['activity'],r['calendar'],r['stress'],r['month']):r for r in ref}
STRESSES=['base','latency1','latency1_slip01','latency5_slip05'];BOOKS={'a':0.,'hybrid':.1,'b':1.}
hour=3600000;day=24*hour
def aggregate(t,v):
 order=np.argsort(t,kind='stable');t=t[order];v=v[order];u,ix=np.unique(t,return_index=True)
 return u,np.add.reduceat(v,ix)
def rolling(t,v,duration):
 t,v=aggregate(t,v);cs=np.r_[0,np.cumsum(v)];left=np.searchsorted(t,t-duration,side='right');s=cs[1:]-cs[left]
 im=int(np.argmax(s));return float(s[im]),int(t[im])
def verify_rolling(t,v,duration):
 tt,vv=aggregate(t,v)
 for i in np.linspace(0,len(tt)-1,min(20,len(tt))).astype(int):
  left=np.searchsorted(tt,tt[i]-duration,side='right')
  a=float(vv[left:i+1].sum());b=float(v[(t>tt[i]-duration)&(t<=tt[i])].sum())
  err=abs(a-b);checks['rolling_oracle_max_error']=max(checks['rolling_oracle_max_error'],err);assert err<1e-6
def rolling_peaks_by_month(t,v,duration,edges):
 t,v=aggregate(t,v);cs=np.r_[0,np.cumsum(v)];left=np.searchsorted(t,t-duration,side='right')
 peaks=np.maximum.accumulate(cs[1:]-cs[left]);kk=np.searchsorted(t,edges,side='right')
 return np.array([peaks[k-1] if k else 0. for k in kk])
monthly=[];concentration=[]
for w in ['w2017','w2019','w2021']:
 tablepath=T/f'v05_{w}.npz';track(tablepath)
 with np.load(tablepath) as z:tables={k:z[k] for k in z.files if k.split('|')[1] in ['gross','comm','fund','Q','exit_ms']}
 start=np.datetime64(f'{w[1:]}-01-02T08:00:00','ms');mo=start.astype('datetime64[M]');offset=start-mo.astype('datetime64[ms]')
 edges=np.array([((mo+m).astype('datetime64[ms]')+offset).astype('int64') for m in range(1,25)])
 for activity in ['fixed','success_reentry']:
  for cal in ['original','hourly_normalized','hourly_same_probability']:
   for product in ['std','crl']:
    path=E/f'{w}__{activity}__{cal}__{product.upper()}.npz';track(path)
    with np.load(path) as z:e={k:z[k] for k in z.files}
    meta=dict(window=w,activity=activity,calendar=cal,product=product)
    ex=e['exit_ms'].astype('int64');iscrl=product=='crl';n=len(ex)
    op=e['e0']*(.0001 if iscrl else .00005)
    abase=e['comm']+e['service']-op;bbase=-e['net']-op
    berr=float(np.max(abs(bbase+e['net']+op)));assert berr<1e-7
    checks['bbook_identity_max_error']=max(checks['bbook_identity_max_error'],berr)
    ix=tuple(e[k].astype(int) for k in ['row','ttl','dir'])
    hit=e['trig']>0
    # Client payments are net trade gains, excluding returned deposited principal.
    tp=ex[e['net']>0];vp=e['net'][e['net']>0]
    pay1=rolling_peaks_by_month(tp,vp,hour,edges);pay24=rolling_peaks_by_month(tp,vp,day,edges)
    if iscrl:
     ht=ex[hit];hp=np.maximum(e['payout_exec'][hit],0);basis=5*e['e0'][hit]/e['price'][hit]*1e-4
     item=dict(meta)
     for label,dur in [('5min',300000),('1h',hour),('5h',5*hour),('24h',day)]:
      item['triggers_'+label],_=rolling(ht,np.ones(len(ht)),dur)
      item['payout_'+label],item['payout_'+label+'_time']=rolling(ht,hp,dur)
     item['pip_loss_basis_1h'],item['pip_loss_basis_1h_time']=rolling(ht,basis,hour)
     item['adverse_execution_1h']={str(pip):pip*item['pip_loss_basis_1h'] for pip in [1,5,10,25]}
     verify_rolling(ht,hp,hour);concentration.append(item)
    for stress in STRESSES:
     if iscrl:
      delayed=e['e0']*(tables[stress+'|gross'][ix]-tables[stress+'|comm'][ix]-tables[stress+'|fund'][ix]-tables[stress+'|Q'][ix]-.000275)
      adj=e['e0']*(tables[stress+'|comm'][ix]-tables['base|comm'][ix])-(e['net']-delayed)
      at=tables[stress+'|exit_ms'][ix].astype('int64');assert np.max(abs(adj[~hit]),initial=0)<1e-7
     else:adj=np.zeros(n);at=ex
     for book,b in BOOKS.items():
      tt=np.r_[ex,at,edges];vv=np.r_[(1-b)*abase+b*bbase,(1-b)*adj,np.full(24,-100000/24)]
      t,v=aggregate(tt,vv);c=np.cumsum(v);running_max=np.maximum.accumulate(np.r_[0,c])[1:];drawdown=running_max-c
      dayids=t//day;ut,daycash=aggregate(dayids,v)
      prev=0.
      for m,edge in enumerate(edges,1):
       k=np.searchsorted(t,edge,side='right');val=float(c[k-1]);hist=c[:k];dd=drawdown[:k]
       # Daily figures only on completed UTC days by each monthly snapshot.
       daily=daycash[(ut>int(start.astype('int64'))//day)&(ut<edge//day)]
       r=dict(meta,stress=stress,book=book,month=m,margin=val/1000,margin_month=(val-prev)/1000,
        cash_proxy_reserve=max(0.,-float(hist.min())),cash_proxy_drawdown=float(dd.max()),worst_completed_UTC_day=min(0.,float(daily.min())) if len(daily) else 0.,negative_completed_UTC_days=int((daily<0).sum()),
        gain_payments_1h=float(pay1[m-1]),gain_payments_24h=float(pay24[m-1]))
       base=lookup[w,activity,cal,stress,m][product]
       expected=(1-b)*base['base_margin']+b*base['b_pure'];err=abs(r['margin']-expected)
       checks['monthly_replay_max_error']=max(checks['monthly_replay_max_error'],err);assert err<1e-5,(meta,stress,book,m,err)
       r['Q']=base['Q'];r['client_assets']=50000+base['net']
       monthly.append(r);prev=val
   print(w,activity,cal,'reconciled',flush=True)
monthly_agg=[]
for stress in STRESSES:
 for book in BOOKS:
  for product in ['std','crl']:
   for month in range(1,25):
    rr=[r for r in monthly if r['stress']==stress and r['book']==book and r['product']==product and r['month']==month];assert len(rr)==18
    fields=['margin','margin_month','Q','client_assets','cash_proxy_reserve','cash_proxy_drawdown','worst_completed_UTC_day','negative_completed_UTC_days','gain_payments_1h','gain_payments_24h']
    x=dict(stress=stress,book=book,product=product,month=month,**{k:float(np.mean([r[k] for r in rr])) for k in fields})
    x.update(margin_min=min(r['margin'] for r in rr),margin_max=max(r['margin'] for r in rr),positive_pairs=sum(r['margin']>0 for r in rr),reserve_max=max(r['cash_proxy_reserve'] for r in rr),drawdown_max=max(r['cash_proxy_drawdown'] for r in rr),worst_day_min=min(r['worst_completed_UTC_day'] for r in rr))
    monthly_agg.append(x)
final=[r for r in monthly_agg if r['month']==24]
concentration_summary={k:dict(mean=float(np.mean([r[k] for r in concentration])),max=max(r[k] for r in concentration),min=min(r[k] for r in concentration)) for k in concentration[0] if k not in ['window','activity','calendar','product','adverse_execution_1h'] and not k.endswith('_time')}
checks.update(status='PASS',event_ledgers=36,monthly_reconciliations=len(monthly),concentration_variants=len(concentration),new_customer_simulations=0,regulatory_or_economic_capital_estimated=False)
write('summary.json',dict(monthly=monthly_agg,final=final,concentration=concentration_summary,checks=checks))
write('monthly_detail.json',monthly);write('concentration_detail.json',concentration);write('checks.json',checks);write('source_hashes.json',hashes)
for name,h in hashes.items():assert digest(R/name)==h
print(json.dumps(checks))
print(json.dumps([r for r in final if r['stress']=='latency5_slip05']))
print(json.dumps(concentration_summary))
