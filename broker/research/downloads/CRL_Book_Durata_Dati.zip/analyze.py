from pathlib import Path
import json,hashlib,importlib.util,time
import numpy as np
P=Path(__file__).resolve().parent;R=P.parent;B=R/'CRL_BBOOK_PREMIUM_FIXED_TRIGGER_20261003';D=R/'CRL_MONTHLY_CLIENT_BROKER_20261002'
def read(p):return json.loads(p.read_text(encoding='utf8'))
def hashfile(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
spec=importlib.util.spec_from_file_location('v06',R/'CRL_5_5_VALIDATION_20261002_CLAUDE/code/v06_accounts.py');M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
cases=read(B/'summary.json')['cases'];policies={'none':None,'loss20':40000,'loss50':25000,'loss80':10000,'loss90':5000,'capital500':500}
ref={(x['window'],x['activity'],x['calendar'],x['month']):x for x in read(D/'broker_data.json')['rows'] if x['stress']=='base'}
pref={(x['window'],x['activity'],x['calendar'],x['case'],x['month']):x for x in read(B/'monthly_detail.json')}
out=[];hashes={'protocol.json':hashfile(P/'protocol.json')};checks=dict(ledger_files=0,cash_conservation_max_error=0.,reference_max_error=0.,no_new_market_simulations=True,no_empirical_churn_claim=True);t0=time.time()
for w in ['w2017','w2019','w2021']:
 edges=M.month_edges(w);start=int(np.datetime64(M.START[w],'ms').astype('int64'));end=edges[-1];bounds=np.r_[start,edges]
 for activity in ['fixed','success_reentry']:
  for cal in ['original','hourly_normalized','hourly_same_probability']:
   for case in ['STD']+[c['case'] for c in cases]:
    file=R/f'CRL_BROKER_REVIEW_CLAUDE/results/events/{w}__{activity}__{cal}__STD.npz' if case=='STD' else B/f'events/{w}__{activity}__{cal}__{case}.npz'
    hashes[str(file.relative_to(R))]=hashfile(file)
    with np.load(file) as z:e={k:z[k] for k in ['client','entry_ms','exit_ms','e0','net']}
    ci=e['client'].astype(int);ex=e['exit_ms'].astype('int64');en=e['entry_ms'].astype('int64');n=len(ci);assert np.all(ci[:-1]<=ci[1:]);ix=np.arange(n);bx=np.searchsorted(edges,ex,side='left');bo=np.searchsorted(edges,en,side='left');cash=e['e0']+e['net'];cost=e['e0']*(.00005 if case=='STD' else .0001)
    def hist(vals,sel,bins=bx):return np.bincount(bins[sel]*1000+ci[sel],weights=vals[sel],minlength=24000).reshape(24,1000)
    for policy,threshold in policies.items():
     stop=np.full(1000,n,dtype=int)
     if threshold is not None:
      sel=cash<=threshold;np.minimum.at(stop,ci[sel],ix[sel])
     exited=stop<n;exit_time=np.full(1000,end+1,dtype='int64');exit_time[exited]=ex[stop[exited]]
     withdrawn=np.zeros(1000);withdrawn[exited]=cash[stop[exited]];keep=ix<=stop[ci]
     net=hist(e['net'],keep);assets=50000+net.cumsum(0);tradecost=hist(cost,keep).cumsum(0);fixed=np.arange(1,25)[:,None]*100/24;broker=-net.cumsum(0)-tradecost-fixed
     exitmask=exit_time[None,:]<=edges[:,None];active=~exitmask;withdrawals=withdrawn[None,:]*exitmask;balance=assets-withdrawals
     assert np.max(np.abs(balance[exitmask]),initial=0)<1e-6;assert balance.min()>-1e-6
     err=float(np.max(abs(assets+broker+tradecost+fixed-50000)));assert err<1e-6;checks['cash_conservation_max_error']=max(checks['cash_conservation_max_error'],err)
     months=np.searchsorted(edges,np.minimum(exit_time,end),side='left');tau=months+(np.minimum(exit_time,end)-bounds[months])/(bounds[months+1]-bounds[months]);assert tau.min()>=0 and tau.max()<=24
     remaining=active.sum(1);assert np.all(np.diff(remaining)<=0)
     openings=hist(np.ones(n),keep,bo)
     for m in range(24):
      row=dict(window=w,activity=activity,calendar=cal,case=case,policy=policy,month=m+1,remaining=int(remaining[m]),exits=int(1000-remaining[m]),new_exits=int((1000-remaining[m])-(1000-remaining[m-1] if m else 0)),restricted_months=float(np.minimum(tau,m+1).mean()),client_assets=float(assets[m].mean()),client_p10=float(np.quantile(assets[m],.1)),client_median=float(np.median(assets[m])),losing=int((assets[m]<50000).sum()),withdrawn_cash=float(withdrawals[m].mean()),account_balance=float(balance[m].mean()),broker=float(broker[m].mean()),broker_month=float((broker[m]-(broker[m-1] if m else 0)).mean()),costs=float((tradecost[m]+fixed[m]).mean()),trading=int((openings[m]>0).sum()),trades=int(openings[m].sum()))
      if policy=='none':
       q=ref[w,activity,cal,m+1]['std'] if case=='STD' else pref[w,activity,cal,case,m+1]
       a=50000+q['net'] if case=='STD' else q['wealth_mean'];br=q['b_pure'] if case=='STD' else q['broker_cumulative'];err=max(abs(a-row['client_assets']),abs(br-row['broker']));assert err<1e-6;checks['reference_max_error']=max(checks['reference_max_error'],err)
      out.append(row)
    checks['ledger_files']+=1
   print(w,activity,cal,'done',round(time.time()-t0),'s',flush=True)
std={(r['window'],r['activity'],r['calendar'],r['policy'],r['month']):r for r in out if r['case']=='STD'}
pairs=[]
for r in out:
 if r['case']=='STD':continue
 s=std[r['window'],r['activity'],r['calendar'],r['policy'],r['month']]
 r=dict(r)
 for k in ['remaining','exits','restricted_months','client_assets','client_p10','losing','broker','broker_month','withdrawn_cash']:r['std_'+k]=s[k]
 r['delta_margin']=r['broker']-s['broker'];r['delta_assets']=r['client_assets']-s['client_assets'];r['delta_lifetime']=r['restricted_months']-s['restricted_months'];r['avoided_exit_rate']=(s['exits']-r['exits'])/1000
 r['required_net_value_per_avoided_exit']=max(0,-r['delta_margin']/r['avoided_exit_rate']) if r['avoided_exit_rate']>0 else (0 if r['delta_margin']>=0 else None)
 pairs.append(r)
monthly=[];numeric=[k for k,v in pairs[0].items() if isinstance(v,(int,float)) and k not in ['month','required_net_value_per_avoided_exit']]
for case in cases:
 for policy in policies:
  for month in range(1,25):
   rr=[r for r in pairs if r['case']==case['case'] and r['policy']==policy and r['month']==month];assert len(rr)==18
   a=dict(case=case['case'],kind=case['kind'],value=case['value'],policy=policy,month=month,**{k:float(np.mean([r[k] for r in rr])) for k in numeric})
   a['required_net_value_per_avoided_exit']=max(0,-a['delta_margin']/a['avoided_exit_rate']) if a['avoided_exit_rate']>0 else (0 if a['delta_margin']>=0 else None)
   a.update(margin_positive_pairs=sum(r['broker']>0 for r in rr),margin_better_pairs=sum(r['delta_margin']>0 for r in rr),lifetime_longer_pairs=sum(r['delta_lifetime']>1e-9 for r in rr),joint_lifetime_margin_positive_pairs=sum(r['delta_lifetime']>1e-9 and r['broker']>0 for r in rr),joint_lifetime_margin_better_pairs=sum(r['delta_lifetime']>1e-9 and r['delta_margin']>0 for r in rr),delta_lifetime_min=min(r['delta_lifetime'] for r in rr),delta_margin_min=min(r['delta_margin'] for r in rr),delta_margin_max=max(r['delta_margin'] for r in rr))
   a['external_value_sensitivity']={str(v):a['delta_margin']+a['avoided_exit_rate']*v for v in read(P/'protocol.json')['V_grid_USD_per_avoided_exit']};monthly.append(a)
assert len(pairs)==17*18*6*24
# The technical rule must match the original no-exit model if it has no observed crossing.
none={(r['case'],r['window'],r['activity'],r['calendar'],r['month']):r for r in out if r['policy']=='none'}
for r in out:
 if r['policy']=='capital500' and r['exits']==0:
  b=none[r['case'],r['window'],r['activity'],r['calendar'],r['month']]
  assert all(abs(r[k]-b[k])<1e-6 for k in ['broker','client_assets','remaining','restricted_months'])
checks.update(status='PASS',paired_monthly_rows=len(pairs),account_scenario_evaluations=18*18*6,tariffs=17,policies=6,source_ledger_hashes=len(hashes)-1,independent_review=False)
summary=dict(cases=[{k:r[k] for k in ['case','kind','value']} for r in cases],policies=policies,monthly=monthly,final=[r for r in monthly if r['month']==24],checks=checks)
for name,x in [('summary.json',summary),('monthly_detail.json',pairs),('checks.json',checks),('source_hashes.json',hashes)]: (P/name).write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(checks));print(json.dumps([r for r in summary['final'] if r['case'] in ['base','q5','q7.5'] and r['policy'] in ['none','loss20','loss50']],ensure_ascii=False))
