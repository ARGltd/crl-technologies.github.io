"""Verify direct broker receipts/payouts independently of the net-P&L shortcut."""
from pathlib import Path
import json,importlib.util
import numpy as np
P=Path(__file__).resolve().parent;R=P.parent
spec=importlib.util.spec_from_file_location('v06',R/'CRL_5_5_VALIDATION_20261002_CLAUDE/code/v06_accounts.py');M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
rows=json.loads((P/'monthly_detail.json').read_text(encoding='utf8'));ix={(r['window'],r['activity'],r['calendar'],r['case'],r['policy'],r['month']):r for r in rows};thresholds={'none':None,'loss20':40000,'loss50':25000,'loss80':10000,'loss90':5000,'capital500':500};maxerr=0.;checks=0
for w in ['w2017','w2019','w2021']:
 edges=M.month_edges(w)
 for a in ['fixed','success_reentry']:
  for c in ['original','hourly_normalized','hourly_same_probability']:
   for case in ['STD','base','q5','q7.5']:
    file=R/f'CRL_BROKER_REVIEW_CLAUDE/results/events/{w}__{a}__{c}__STD.npz' if case=='STD' else R/f'CRL_BBOOK_PREMIUM_FIXED_TRIGGER_20261003/events/{w}__{a}__{c}__{case}.npz'
    with np.load(file) as z:
     e={k:z[k] for k in ['client','exit_ms','e0','net','comm','service','fund','gross']};prem=z['Q'] if case=='STD' else z['premium']
    # STD has no Q cash premium; verify it explicitly.
    if case=='STD':assert np.max(abs(prem))<1e-10
    ci=e['client'].astype(int);bx=np.searchsorted(edges,e['exit_ms'],side='left');receipts=e['comm']+e['service']+e['fund']+prem-e['gross']-e['e0']*(.00005 if case=='STD' else .0001)
    startidx=np.r_[0,np.flatnonzero(np.diff(ci))+1];ends=np.r_[startidx[1:],len(ci)]
    for pol,t in thresholds.items():
     keep=np.zeros(len(ci),dtype=bool)
     for left,right in zip(startidx,ends):
      limit=right
      if t is not None:
       crossed=np.flatnonzero(e['e0'][left:right]+e['net'][left:right]<=t)
       if len(crossed):limit=left+crossed[0]+1
      keep[left:limit]=True
     totals=np.bincount(bx[keep],weights=receipts[keep],minlength=24).cumsum()/1000-np.arange(1,25)*100/24
     for m,v in enumerate(totals,1):
      r=ix[w,a,c,'base' if case=='STD' else case,pol,m];target=r['std_broker'] if case=='STD' else r['broker'];err=abs(v-target);maxerr=max(maxerr,err);assert err<1e-6,(w,a,c,case,pol,m,v,target);checks+=1
(P/'direct_cash_checks.json').write_text(json.dumps(dict(status='PASS',direct_monthly_broker_comparisons=checks,max_error=maxerr,cases=['STD','base','q5','q7.5'],all18_variants_and_six_policies=True),indent=2));print('Direct cash checks:',checks,'max error',maxerr)
