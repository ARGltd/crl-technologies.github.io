from pathlib import Path
import numpy as np,json,hashlib
P=Path(__file__).resolve().parent;R=P.parent
z=np.load(P/'monthly_pairs.npz');a=z['values'];fields=list(z['fields']);keys=z['keys']
at=lambda p,k:a[:,:,fields.index(p+k)]
maxerr=0.
for prefix in ['s_','c_']:
 arrivals=at(prefix,'arrivals');acq=at(prefix,'acquired');active=at(prefix,'active');exits=at(prefix,'exits')
 assert np.max(abs(acq-np.cumsum(arrivals,axis=1)))<1e-10
 assert np.max(abs(active+exits-acq))<1e-10
 assert active.max()<=1+1e-10 and active.min()>=0
 for C in [0,1267,5000,20000]:
  # Money conservation with marketing money paid out of broker margin.
  residual=at(prefix,'all_assets')+at(prefix,'margin')-C*acq+at(prefix,'costs')+C*acq-at(prefix,'deposits')
  maxerr=max(maxerr,float(np.max(abs(residual))));assert maxerr<1e-6
 # Recursive exits must generate next arrivals, with the exact chosen calendar lag.
 monthly_exits=np.diff(np.c_[np.zeros(len(a)),exits],axis=1)
 for i,k in enumerate(keys):
  lag={'closed':None,'next_month':0,'wait1':1,'wait3':3,'wait6':6}[k[2]]
  if lag is None:assert np.max(abs(arrivals[i,1:]))==0
  else:
   expected=np.r_[np.zeros(lag+1),monthly_exits[i,:23-lag]]
   expected[0]=1
   assert np.max(abs(expected-arrivals[i]))<1e-10
  if k[1] in ['none','capital500']:
   assert acq[i,-1]==1
for name,h in json.loads((P/'source_hashes.json').read_text()).items():
 assert hashlib.sha256((R/name).read_bytes()).hexdigest()==h
opt=json.loads((P/'optional_replacement_checks.json').read_text())
assert opt['status']=='PASS'
import ast,itertools
tree=ast.parse((P/'verify_optional.py').read_text(encoding='utf8'))
ns={'np':np}
exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='dp'],type_ignores=[]),'optional_dp','exec'),ns)
oracle_checks=0
for f,g in [(np.array([1.,0.,0.,0.]),np.array([100.,100.,100.,100.])),(np.array([.3,.2,.1,0]),np.array([-30.,80.,200.,250.]))]:
 for lag in [0,1,3]:
  for C in [0,50,100,180,400]:
   alternatives=[]
   for bits in itertools.product([0,1],repeat=4):
    vv=[0.]
    for j in range(1,5):
     q=j-1-lag
     raw=g[j-1]-C+sum(f[k-1]*vv[j-k-lag] for k in range(1,max(0,q)+1))
     vv.append(raw if bits[j-1] else 0.)
    alternatives.append(vv[-1])
   assert abs(ns['dp'](f,g,lag,C,h=4)[-1]-max(alternatives))<1e-8
   oracle_checks+=1
out=dict(status='PASS',monthly_cash_identity_including_CAC_max_error=maxerr,all_renewal_flows_reconciled=True,all_source_hashes_unchanged=True,optional_acquisition_checked=True,optional_small_horizon_exhaustive_oracles=oracle_checks,independent_review=False)
(P/'verification.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out))
