"""Expected monthly cohort renewal, not a new market-path simulation."""
from pathlib import Path
import json, hashlib
import numpy as np

P=Path(__file__).resolve().parent
R=P.parent
L=R/'CRL_BBOOK_LIFETIME_20261003'
def read(p): return json.loads(p.read_text(encoding='utf8'))
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,x): (P/name).write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf8')
protocol=read(P/'protocol.json')
inputs=[L/'monthly_detail.json',L/'protocol.json',L/'checks.json',L/'direct_cash_checks.json',P/'protocol.json']
write('source_hashes.json',{str(p.relative_to(R)):digest(p) for p in inputs})
assert read(L/'checks.json')['status']=='PASS'
rows=read(L/'monthly_detail.json')
groups={}
for r in rows: groups.setdefault((r['case'],r['policy'],r['window'],r['activity'],r['calendar']),[]).append(r)
for rr in groups.values():
 rr.sort(key=lambda x:x['month']); assert [x['month'] for x in rr]==list(range(1,25))
cases=read(L/'summary.json')['cases']; policies=list(read(L/'summary.json')['policies'])
fixed=np.arange(1,25)*100/24
checks={'max_cash_error':0.,'max_direct_sum_error':0.,'max_closed_replay_error':0.,'product_paths_changed':False,'calendar_aligned_backtest':False}

def renew(rr,prefix,lag):
 def arr(k): return np.array([r[prefix+k] for r in rr],dtype=float)
 survival=arr('remaining')/1000
 cdf=1-survival; exitmass=np.diff(np.r_[0,cdf]); assert exitmass.min()>-1e-12
 arrivals=np.zeros(24); arrivals[0]=1
 if lag is not None:
  for t in range(1,24):
   j=t-lag
   if j>0: arrivals[t]=np.dot(arrivals[:j],exitmass[:j][::-1])
 def conv(a): return np.convolve(arrivals,a)[:24]
 # Independent explicit cohort matrix: cohorts at rows, calendar months at columns.
 def direct(a):
  z=np.zeros((24,24))
  for t in range(24): z[t,t:]=arrivals[t]*a[:24-t]
  return z.sum(axis=0)
 acquired=np.cumsum(arrivals); active=conv(survival); exits=conv(cdf)
 assert np.max(abs(active-(acquired-exits)))<1e-10 and active.max()<=1+1e-10
 assets=arr('client_assets'); broker=arr('broker'); costs=50000-assets-broker
 pnl=conv(assets-50000); allassets=50000*acquired+pnl
 margin=conv(broker+fixed)-fixed
 variable=conv(costs-fixed); totalcost=variable+fixed
 withdrawal=conv(arr('withdrawn_cash')); account=allassets-withdrawal
 err=np.max(abs(allassets+margin+totalcost-50000*acquired));checks['max_cash_error']=max(checks['max_cash_error'],float(err));assert err<1e-6
 assert account.min()>-1e-6
 for a in [survival,cdf,assets-50000,broker+fixed,costs-fixed,arr('withdrawn_cash')]:
  err=np.max(abs(conv(a)-direct(a)));checks['max_direct_sum_error']=max(checks['max_direct_sum_error'],float(err));assert err<1e-6
 # Fixed overhead alternative: original amount plus cost of each replacement acquisition.
 extra_fixed=conv(fixed)-fixed
 if lag is None:
  err=max(np.max(abs(margin-broker)),np.max(abs(allassets-assets)))
  checks['max_closed_replay_error']=max(checks['max_closed_replay_error'],float(err));assert err<1e-6
 if cdf[-1]==0:
  assert np.sum(arrivals)==1 and np.max(abs(margin-broker))<1e-6
 return dict(acquired=acquired,arrivals=arrivals,active=active,exits=exits,margin=margin,
  extra_fixed=extra_fixed,original_assets=assets,original_broker=broker,original_lifetime=arr('restricted_months'),
  all_pnl=pnl,all_assets=allassets,deposits=50000*acquired,withdrawals=withdrawal,account=account,costs=totalcost)

def interval(r,require_std=False,extra=False):
 """Open inequalities except C>=0; equality never qualifies."""
 if r['c_original_assets']<=r['s_original_assets']+1e-8: return {'feasible':False,'reason':'client_assets'}
 if r['c_original_lifetime']<=r['s_original_lifetime']+1e-8: return {'feasible':False,'reason':'lifetime'}
 cm=r['c_margin']-(r['c_extra_fixed'] if extra else 0)
 sm=r['s_margin']-(r['s_extra_fixed'] if extra else 0)
 cn,sn=r['c_acquired'],r['s_acquired']
 lower,upper=0.,float('inf')
 constraints=[(cm-sm,sn-cn),(cm,-cn)]+([(sm,-sn)] if require_std else [])
 for a,b in constraints:
  if abs(b)<1e-12:
   if a<=0: return {'feasible':False,'reason':'margin'}
  elif b>0: lower=max(lower,-a/b)
  else: upper=min(upper,-a/b)
 if upper<=lower: return {'feasible':False,'reason':'no_profitable_CAC_interval','lower':lower,'upper':upper}
 return {'feasible':True,'lower':lower,'upper':upper,'zero_passes':all(a>0 for a,b in constraints)}

detail=[]; curve_arrays=[]; curve_keys=[]
fields=None
for key,rr in groups.items():
 case,policy,w,a,cal=key
 for mode,lag in protocol['replacement_modes'].items():
  s=renew(rr,'std_',lag); c=renew(rr,'',lag)
  fields=[p+k for p in ['s_','c_'] for k in s]
  curve_arrays.append(np.stack([d[k] for d in [s,c] for k in s],axis=-1));curve_keys.append([case,policy,mode,w,a,cal])
  d=dict(case=case,policy=policy,mode=mode,window=w,activity=a,calendar=cal)
  d.update({p+k:float(v[-1]) for p,x in [('s_',s),('c_',c)] for k,v in x.items()})
  detail.append(d)
curves=np.stack(curve_arrays)
np.savez_compressed(P/'monthly_pairs.npz',values=curves,fields=np.array(fields),keys=np.array(curve_keys))
write('final_pairs.json',detail)
bykey={}
for i,k in enumerate(curve_keys):bykey.setdefault(tuple(k[:3]),[]).append(i)
monthly=[]; final=[]
cacs=[0,500,1267,2500,5000,10000,15000,20000]
for key,ii in bykey.items():
 assert len(ii)==18
 vals=curves[ii].mean(axis=0)
 for m in range(24):
  r=dict(case=key[0],policy=key[1],mode=key[2],month=m+1,**dict(zip(fields,map(float,vals[m]))))
  r['cac_saved_count']=r['s_acquired']-r['c_acquired']
  r['delta_margin_before_cac']=r['c_margin']-r['s_margin']
  r['delta_original_assets']=r['c_original_assets']-r['s_original_assets']
  r['delta_original_lifetime']=r['c_original_lifetime']-r['s_original_lifetime']
  r['delta_original_margin']=r['c_original_broker']-r['s_original_broker']
  r['delta_replacement_margin']=r['delta_margin_before_cac']-r['delta_original_margin']
  r['interval']=interval(r);r['both_profitable_interval']=interval(r,True);r['extra_fixed_interval']=interval(r,False,True)
  if m==23:
   pp=[detail[i] for i in ii];iv=[interval(x,True) for x in pp]
   r['all18_both_profitable_interval']={'feasible':False}
   if all(x['feasible'] for x in iv):
    lo=max(x['lower'] for x in iv);hi=min(x['upper'] for x in iv)
    r['all18_both_profitable_interval']=dict(feasible=hi>lo,lower=lo,upper=hi)
   r['sensitivity']=[]
   for C in cacs:
    def passes(x):return x['c_original_assets']>x['s_original_assets'] and x['c_original_lifetime']>x['s_original_lifetime'] and x['c_margin']-C*x['c_acquired']>max(0,x['s_margin']-C*x['s_acquired'])
    r['sensitivity'].append(dict(cac=C,std=r['s_margin']-C*r['s_acquired'],crl=r['c_margin']-C*r['c_acquired'],delta=r['delta_margin_before_cac']+C*r['cac_saved_count'],joint_pairs=sum(passes(x) for x in pp),mean_pass=passes(r)))
   if r['interval']['feasible']:
    C=(r['interval']['lower']+r['interval']['upper'])/2
    assert r['c_margin']-C*r['c_acquired']>max(0,r['s_margin']-C*r['s_acquired'])
   final.append(r)
  monthly.append(r)
checks.update(status='PASS',paired_curves=len(curve_keys),paired_monthly_observations=int(curves.shape[0]*24),aggregate_monthly_rows=len(monthly),tariffs=len(cases),policies=len(policies),replacement_modes=5,independent_review=False)
write('summary.json',dict(cases=cases,policies=policies,modes=protocol['replacement_modes'],monthly=monthly,final=final,checks=checks))
write('checks.json',checks)
for name,h in read(P/'source_hashes.json').items():assert digest(R/name)==h
print(json.dumps(checks))
for r in final:
 if r['case']=='base' and r['policy'] in ['loss20','loss50']:
  print(json.dumps({k:r[k] for k in ['case','policy','mode','s_margin','c_margin','s_acquired','c_acquired','delta_original_assets','interval','both_profitable_interval','all18_both_profitable_interval']}))
print('Feasible mean/all18/at1267:',sum(r['interval']['feasible'] for r in final),sum(r['all18_both_profitable_interval']['feasible'] for r in final),sum(r['sensitivity'][2]['mean_pass'] for r in final))
