"""Original premium: allow the broker to reject uneconomic replacements.

Dynamic programme under the same stationary cohort forecast, not perfect
foresight over actual future customer paths. All possible CAC >=0 covered
by the piecewise-affine value function, within numeric tolerance.
"""
from pathlib import Path
import json
import numpy as np
P=Path(__file__).resolve().parent
S=json.loads((P/'summary.json').read_text(encoding='utf8'))
z=np.load(P/'monthly_pairs.npz');K=z['keys'];V=z['values'];F=list(z['fields'])
out=[];eps=1e-7
def kernels(i,p):
 v=V[i];sur=v[:,F.index(p+'active')];f=np.diff(np.r_[0,1-sur]);g=v[:,F.index(p+'margin')]+np.arange(1,25)*100/24
 return f,g
def dp(f,g,lag,C,h=24):
 v=np.zeros(h+1)
 for j in range(1,h+1):
  q=j-1-lag
  continuation=np.dot(f[:q],v[q:0:-1]) if q>0 else 0.
  v[j]=max(0,g[j-1]-C+continuation)
 return v
def initial(f,g,lag,C):
 v=dp(f,g,lag,C);q=23-lag
 return g[-1]-C+(np.dot(f[:q],v[q:0:-1]) if q>0 else 0)-100
def switches(f,g,lag):
 roots=[0.]
 for h in range(1,25):
  def raw(C):
   v=dp(f,g,lag,C,h-1);q=h-1-lag
   return g[h-1]-C+(np.dot(f[:q],v[q:0:-1]) if q>0 else 0)
  if raw(0)<=0:continue
  lo,hi=0.,max(1.,float(np.max(g))+1)
  assert raw(hi)<0
  for _ in range(46):
   mid=(lo+hi)/2
   if raw(mid)>0:lo=mid
   else:hi=mid
  roots.append((lo+hi)/2)
 return roots
for policy in S['policies']:
 ii=[i for i,k in enumerate(K) if k[0]=='base' and k[1]==policy and k[2]=='closed']
 assert len(ii)==18
 original=next(r for r in S['final'] if r['case']=='base' and r['policy']==policy and r['mode']=='closed')
 gate=original['delta_original_assets']>0 and original['delta_original_lifetime']>eps
 for lag in [0,1,3,6]:
  pairs=[(kernels(i,'s_'),kernels(i,'c_')) for i in ii]
  def values(C):return np.array([[initial(*s,lag,C),initial(*c,lag,C)] for s,c in pairs])
  sensitivity=[dict(cac=C,std=float(values(C)[:,0].mean()),crl=float(values(C)[:,1].mean())) for C in [0,500,1267,2500,5000,10000,15000,20000]]
  regions=[];knots=[]
  if gate:
   knots=sorted(set(x for pair in pairs for fg in pair for x in switches(*fg,lag)))
   knots.append(knots[-1]+max(50000,knots[-1]))
   val=np.array([values(C).mean(axis=0) for C in knots])
   for j in range(len(knots)-1):
    # On each segment, both CRL profit and its advantage are affine.
    lo,hi=0.,1.
    for col in [val[:,1],val[:,1]-val[:,0]]:
     a=col[j];b=col[j+1]-a
     if abs(b)<1e-10:
      if a<=eps:hi=-1;break
     elif b>0:lo=max(lo,(eps-a)/b)
     else:hi=min(hi,(eps-a)/b)
    if hi>lo:
     regions.append([knots[j]+lo*(knots[j+1]-knots[j]),knots[j]+hi*(knots[j+1]-knots[j])])
   # Above largest switch, nobody replaces; both initial-cohort profits decline.
   assert np.max(val[-1])<0
  # Option to leave capacity empty cannot lower expected broker profit.
  for C in [0,1267,5000,20000]:
   vv=values(C)
   for h,i in enumerate(ii):
    for n,p in enumerate(['s_','c_']):
     assert vv[h,n]>=V[i,-1,F.index(p+'margin')]-C-1e-6
  out.append(dict(case='base',policy=policy,lag=lag,customer_lifetime_gate=gate,feasible_CAC_intervals=regions,switch_points=len(knots),sensitivity=sensitivity))
  print(policy,lag,'regions',regions,flush=True)
result=dict(status='PASS',scope='Original premium, six exit scenarios, four replacement delays, all18 historical variants. Common CAC>=0; cohort-age forecast assumed stationary.',method='Dynamic optional replacement; complete piecewise-affine mean-profit frontier. Tolerance1e-7 USD. No empirical calibration.',rows=out,any_mean_joint_solution=any(r['feasible_CAC_intervals'] for r in out))
(P/'optional_replacement_checks.json').write_text(json.dumps(result,indent=2),encoding='utf8')
