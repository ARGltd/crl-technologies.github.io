const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const P=__dirname,D=path.join(P,'../CRL_MONTHLY_CLIENT_BROKER_20261002');
const els={};const document={getElementById(id){return els[id]??={value:id==='relCase'?'base':id==='relCac'?'0':'',innerHTML:'',textContent:'',events:{},addEventListener(name,fn){this.events[name]=fn;}};}};
const ctx={document,window:{},console};vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(D,'relation_data.js'),'utf8'),ctx);
vm.runInContext(fs.readFileSync(path.join(D,'relation.js'),'utf8'),ctx);
assert(els.relCase.innerHTML.includes('0,10 bp del capitale'));
assert(!els.relCase.innerHTML.includes('0,900% del premio Q'));
let s=JSON.parse(fs.readFileSync(path.join(P,'summary.json'))),comparisons=0,views=0;
for(const r of s.final){
 for(const q of r.sensitivity){
  const v=ctx.window.CRL_RELATION_EVALUATE(r,q.cac);
  assert(Math.abs(v.s-q.std)<1e-7&&Math.abs(v.c-q.crl)<1e-7&&Math.abs(v.delta-q.delta)<1e-7);
  assert(v.pass===q.mean_pass);comparisons++;
 }
 els.relCase.value=r.case;els.relPolicy.value=r.policy;els.relMode.value=r.mode;els.relCac.value='1267';
 els.relCac.events.change();
 for(const id of ['relKpis','relMonthly','relCash','relBridge','relTariffs','relAssets','relMargin'])assert(!/NaN|undefined|Infinity/.test(els[id].innerHTML),id);
 assert((els.relMonthly.innerHTML.match(/<tr>/g)||[]).length===25);
 assert((els.relTariffs.innerHTML.match(/<tr>/g)||[]).length===18);views++;
}
const out={status:'PASS',accounting_comparisons:comparisons,rendered_views:views,tariff_units_verified:true,monthly_rows_per_view:24};
fs.writeFileSync(path.join(P,'ui_checks.json'),JSON.stringify(out,null,2));console.log(JSON.stringify(out));
