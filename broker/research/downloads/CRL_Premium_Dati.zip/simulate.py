"""Re-run entry decisions and balances; only the CRL upfront premium changes.
Per-client event loop follows the independently verified r01 account algorithm.
All realized cash flows are saved for validation and monthly reporting.
"""
from pathlib import Path
import json,sys,math,time,importlib.util
import numpy as np
import pandas as pd
P=Path(__file__).resolve().parent;R=P.parent
V=R/'CRL_5_5_VALIDATION_20261002_CLAUDE/results'
spec=importlib.util.spec_from_file_location('v06',V.parent/'code/v06_accounts.py');M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
HOUR=M.HOUR;DAY=M.DAY
FL=['exit_ms','gross','comm','fund','Q','minfactor','trigger','hours']
COL=['client','entry_ms','exit_ms','row','ttl','dir','e0','net','extra','premium','comm','fund','service','ops','licence','minimum','trig','gross']

def run(w):
 t0=time.time();(P/'events').mkdir(exist_ok=True);(P/'results').mkdir(exist_ok=True)
 cases=[c for c in json.loads((P/'admissibility.json').read_text())['cases'] if c['admissible']]
 ro=pd.read_csv(M.V6/'results/w2017__sl0125_tp025__base/anagrafica.csv');nums=[int(x[1:]) for x in ro.trader_id];n=len(nums)
 ti=np.array([M.ROSTER_TTL.index(v) for v in ro.ttl_hours]);prob=ro.entry_probability.to_numpy(float);fam=ro.signal_family.tolist()
 man=json.loads((M.MK[w]/'manifest.json').read_text());N=man['records'];t=np.load(M.MK[w]/'t.npy',mmap_mode='r')[:N];bid=np.load(M.MK[w]/'bid.npy',mmap_mode='r')[:N];ask=np.load(M.MK[w]/'ask.npy',mmap_mode='r')[:N]
 with np.load(V/f'v03_{w}.npz') as z:orig=z['original_slots'];raw=z['raw_slots'];keep=z['keep'];kept=raw[keep]
 u0,a,b=M.draws(M.SEED0,nums,len(orig));d0=M.directions(fam,a,b,M.trend(t,bid,ask,orig));del a,b
 u1,a,b=M.draws(M.SEED1,nums,len(raw));d1=M.directions(fam,a,b,M.trend(t,bid,ask,raw));del a,b
 pos=np.searchsorted(raw,orig);assert np.array_equal(raw[pos],orig);u1[pos]=u0;d1[pos]=d0;u1=u1[keep];d1=d1[keep]
 opos=np.searchsorted(kept,orig);assert np.array_equal(kept[opos],orig)
 with np.load(V/f'v05_{w}.npz') as z:tab={f:z['base|'+f] for f in FL}
 start=int(np.datetime64(M.START[w],'ms').astype('int64'));edges=M.month_edges(w);edges=edges[1:] if len(edges)==25 else edges
 assert len(edges)==24
 output=[];checks=dict(window=w,runs=0,events=0,baseline_max_error=0.,baseline_events_exact=True,max_conservation_error=0.,trigger_nonpositive=0)
 for activity in ['fixed','success_reentry']:
  for calendar in ['original','hourly_normalized','hourly_same_probability']:
   if calendar=='original':slots=orig;U=u0;DIR=d0;rows=opos
   else:slots=kept;U=u1;DIR=d1;rows=np.arange(len(kept))
   S=len(slots);sday=slots//DAY;di=((DIR+1)//2).astype(int);G=np.stack([tab[f][rows] for f in FL],axis=-1)
   fin=np.isfinite(G[np.arange(S)[:,None],ti[None,:],di,0])
   def nxt(success):
    pe=np.minimum(1.,prob*(math.exp(.177) if success else 1.))
    if calendar=='hourly_normalized':pe=1-np.power(1-pe,4/13)
    candidates=(U<pe[None,:])&fin;ix=np.where(candidates,np.arange(S)[:,None],S)
    return np.vstack([np.minimum.accumulate(ix[::-1],axis=0)[::-1],np.full((1,n),S)])
   N0=nxt(False);sr=activity=='success_reentry';N1=nxt(True) if sr else N0
   first_start=int(np.searchsorted(slots,start,side='left'))
   for case in cases:
    ev=[];extrarate=case['value']/10000 if case['kind']=='flat_bp' else None
    for c in range(n):
     equity=50000.;X=None;days={};last_days=[]
     while True:
      if X is None:k=N0[first_start,c]
      else:
       D=X//DAY;stA=days[last_days[-2]]>0 if len(last_days)>=2 else False;stB=days[D]>0
       eA=X if(stA and sr)else X+4*HOUR;sA=int(np.searchsorted(slots,eA,side='left'));cand=(N1 if stA else N0)[sA,c]
       if cand<S and sday[cand]==D:k=cand
       else:
        eB=max((D+1)*DAY,X if(stB and sr)else X+4*HOUR);k=(N1 if stB else N0)[int(np.searchsorted(slots,eB,side='left')),c]
      if k>=S:break
      ex,gross,comm,fund,Q,mf,trig,hrs=G[k,ti[c],di[k,c]]
      extra=extrarate if extrarate is not None else Q*case['value']/100
      net=gross-comm-fund-Q-2.75e-4-extra;e0=equity;equity=e0*(1+net)
      minimum=e0*min(mf-Q-2.75e-4-extra,1+net)
      ev.append((c,int(slots[k]),int(ex),int(rows[k]),int(ti[c]),int(di[k,c]),e0,e0*net,e0*extra,e0*(Q+extra),e0*comm,e0*fund,e0*2.75e-4,e0*.5e-4,e0*.5e-4,minimum,trig,e0*gross))
      X=int(ex);D=X//DAY
      if D not in days:days[D]=0.;last_days.append(D)
      days[D]+=e0*net
      if equity<=500:break
    E=np.asarray(ev);e={k:E[:,j] for j,k in enumerate(COL)};ci=e['client'].astype(int);en=e['entry_ms'].astype('int64');ex=e['exit_ms'].astype('int64');same=ci[1:]==ci[:-1]
    assert np.all(en[1:][same]>=ex[:-1][same]);assert np.all(e['e0']>0)
    checks['trigger_nonpositive']+=int(((e['trig']>0)&(e['net']<=0)).sum());assert checks['trigger_nonpositive']==0
    if case['id']=='base':
     with np.load(R/f'CRL_BROKER_REVIEW_CLAUDE/results/events/{w}__{activity}__{calendar}__CRL.npz') as old:
      for f in ['client','entry_ms','exit_ms','row','ttl','dir']:assert np.array_equal(e[f],old[f]),f
      for f in ['e0','net','comm','fund','service','minimum','trig','gross']:
       err=float(np.max(np.abs(e[f]-old[f])));assert err<1e-6,(f,err);checks['baseline_max_error']=max(checks['baseline_max_error'],err)
    bx=np.searchsorted(edges,ex,side='left');bo=np.searchsorted(edges,en,side='left');assert bx.max()<24 and bo.max()<24
    def hist(vals,bins=bx):return np.bincount(bins*1000+ci,weights=vals,minlength=24000).reshape(24,1000)
    netm=hist(e['net']);wealth=50000+np.cumsum(netm,axis=0);ops=np.cumsum(hist(e['ops']+e['licence']),axis=0);fixed=np.arange(1,25)[:,None]*100/24
    broker=np.cumsum(hist(e['comm']+e['fund']+e['service']+e['premium']-e['gross']-e['ops']-e['licence']),axis=0)-fixed
    error=float(np.max(np.abs(wealth+broker+ops+fixed-50000)));assert error<1e-6;checks['max_conservation_error']=max(checks['max_conservation_error'],error)
    extra_cum=np.cumsum(hist(e['extra']),axis=0);opens=hist(np.ones(len(ci)),bo);burns={}
    for level in [20,50,80,90]:
     first=np.full(n,edges[-1]+1,dtype='int64');sel=e['minimum']<=50000*(1-level/100);np.minimum.at(first,ci[sel],ex[sel]);burns[level]=(first[None,:]<=edges[:,None]).sum(axis=1)
    basekey=dict(window=w,activity=activity,calendar=calendar,case=case['id'])
    for m in range(24):
     mask=(bx==m)&(e['trig']>0)
     output.append(dict(basekey,month=m+1,wealth_mean=float(wealth[m].mean()),wealth_median=float(np.median(wealth[m])),wealth_p10=float(np.quantile(wealth[m],.1)),losing=int((wealth[m]<50000).sum()),losing_month=int((netm[m]<0).sum()),trading=int((opens[m]>0).sum()),trades=int(opens[m].sum()),broker_cumulative=float(broker[m].mean()),broker_month=float((broker[m]-(broker[m-1] if m else 0)).mean()),costs_cumulative=float((ops[m]+fixed[m]).mean()),premium_extra_cumulative=float(extra_cum[m].mean()),**{f'burn{k}':int(v[m]) for k,v in burns.items()},min_trigger_net_usd=float(e['net'][mask].min()) if mask.any() else None,min_trigger_net_bp=float((e['net'][mask]/e['e0'][mask]).min()*10000) if mask.any() else None,trigger_count=int(mask.sum())))
    np.savez_compressed(P/'events'/f'{w}__{activity}__{calendar}__{case["id"]}.npz',**e)
    checks['runs']+=1;checks['events']+=len(ci)
    print(w,activity,calendar,case['id'],round(float(wealth[-1].mean()),2),round(float(broker[-1].mean()),2),round(time.time()-t0),'s',flush=True)
 (P/'results'/f'{w}.json').write_text(json.dumps(dict(rows=output,checks=checks)),encoding='utf8')
 print(w,'COMPLETE',json.dumps(checks),flush=True)
if __name__=='__main__':run(sys.argv[1])
