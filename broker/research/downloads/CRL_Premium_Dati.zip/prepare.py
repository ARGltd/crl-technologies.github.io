from pathlib import Path
import json, hashlib, importlib.util
import numpy as np
P=Path(__file__).resolve().parent;R=P.parent;V=R/'CRL_5_5_VALIDATION_20261002_CLAUDE/results'
spec=importlib.util.spec_from_file_location('contracts',V.parent/'code/v03_contracts.py');C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)
protocol=json.loads((P/'protocol.json').read_text())
qgrid=protocol['Q_loading_percent_grid']+json.loads((P/'protocol_addendum.json').read_text())['additional_Q_loading_percent_grid']
cases=[dict(id='base',kind='flat_bp',value=0)]+[dict(id=f'bp{x:g}',kind='flat_bp',value=x) for x in protocol['flat_bp_grid'] if x]+[dict(id=f'q{x:g}',kind='Q_percent',value=x) for x in qgrid]
report=[];hashes={};net_ceiling=[];q_ceiling=[]
for w in ['w2017','w2019','w2021']:
 a=V/f'v03_{w}.npz';b=V/f'v05_{w}.npz'
 hashes[str(a.relative_to(R))]=hashlib.sha256(a.read_bytes()).hexdigest();hashes[str(b.relative_to(R))]=hashlib.sha256(b.read_bytes()).hexdigest()
 with np.load(a) as v,np.load(b) as z:
  valid=np.isfinite(z['base|gross']);trig=valid&(z['base|trigger']>0)
  net=z['base|gross']-z['base|comm']-z['base|fund']-z['base|Q']-2.75e-4
  assert np.all(net[trig]>0)
  # A larger upfront premium cannot reverse an existing losing-at-short-TTL decision.
  # All non-extended expiry cells must already end at the mandatory maximum cutoff.
  expiry=valid&(v['reason|sl05_tp05|NEAR']==3)&(~v['extended|sl05_tp05|NEAR'])
  slots=v['slots'];end=C.utc_ms(C.WIN[w][1]);caps=np.minimum(np.minimum(slots+120*C.HOUR,np.array([C.forced_close(int(s)) for s in slots])),end)
  early=expiry&(z['base|exit_ms']<caps[:,None,None]-60001)
  assert not early.any(), 'Premium may change expiry; contract rebuild required'
  assert np.array_equal(v['sl05_tp05|NEAR|exit_ms'],z['base|exit_ms'],equal_nan=True)
  net_ceiling.append(float(net[trig].min()*10000));q_ceiling.append(float((net[trig]/z['base|Q'][trig]).min()*100))
  for c in cases:
   extra=c['value']/10000 if c['kind']=='flat_bp' else z['base|Q']*c['value']/100
   new=net-extra;report.append(dict(window=w,case=c['id'],min_potential_trigger_net_bp=float(new[trig].min()*10000),nonpositive_potential_cells=int((new[trig]<=1e-12).sum())))
for c in cases:
 rr=[r for r in report if r['case']==c['id']];c.update(admissible=all(r['nonpositive_potential_cells']==0 for r in rr),min_potential_trigger_net_bp=min(r['min_potential_trigger_net_bp'] for r in rr),nonpositive_potential_cells=sum(r['nonpositive_potential_cells'] for r in rr))
out=dict(cases=cases,flat_bp_historical_strict_ceiling=min(net_ceiling),Q_percent_historical_strict_ceiling=min(q_ceiling),window_checks=report,contract_reuse_justified=True,screen_is_in_sample=True)
(P/'admissibility.json').write_text(json.dumps(out,indent=2),encoding='utf8')
hashes['protocol.json']=hashlib.sha256((P/'protocol.json').read_bytes()).hexdigest()
hashes['protocol_addendum.json']=hashlib.sha256((P/'protocol_addendum.json').read_bytes()).hexdigest()
(P/'source_hashes.json').write_text(json.dumps(hashes,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in out.items() if k!='window_checks'},indent=2))
