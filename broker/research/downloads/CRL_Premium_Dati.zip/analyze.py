from pathlib import Path
import json, hashlib, csv, statistics as st
P=Path(__file__).resolve().parent; R=P.parent; D=R/'CRL_MONTHLY_CLIENT_BROKER_20261002'
def read(p): return json.loads(p.read_text(encoding='utf8'))
def key(r): return tuple(r[k] for k in ['window','activity','calendar','month'])
old={key(r):r for r in read(D/'broker_data.json')['rows'] if r['stress']=='base'}
client={key(r):r for r in read(D/'data.json')['rows'] if r['stress']=='base'}
ad=read(P/'admissibility.json'); cases=[c for c in ad['cases'] if c['admissible']]
rows=[]; runchecks=[]
for w in ['w2017','w2019','w2021']:
 d=read(P/'results'/f'{w}.json'); rows+=d['rows']; runchecks.append(d['checks'])
assert len(rows)==len(cases)*18*24
base={key(r):r for r in rows if r['case']=='base'}
err=0.; delta_err=0.
for r in rows:
 o=old[key(r)]; b=base[key(r)]; c=client[key(r)]
 r.update(std_wealth=c['std']['wealth_mean'],std_wealth_p10=c['std']['wealth_p10'],std_broker=o['std']['b_pure'],std_losing=c['std']['losing'],std_losing_month=c['std']['losing_this_month'],std_burn50=c['std']['burn50'],std_trades=c['std']['trades'],base_wealth=b['wealth_mean'],base_broker=b['broker_cumulative'],base_trades=b['trades'])
 r.update(client_delta_std=r['wealth_mean']-r['std_wealth'],broker_delta_std=r['broker_cumulative']-r['std_broker'],client_delta_base=r['wealth_mean']-b['wealth_mean'],broker_delta_base=r['broker_cumulative']-b['broker_cumulative'])
 delta_err=max(delta_err,abs(r['client_delta_base']+r['broker_delta_base']+r['costs_cumulative']-b['costs_cumulative']))
 if r['case']=='base':
  err=max(err,abs(r['wealth_mean']-c['crl']['wealth_mean']),abs(r['broker_cumulative']-o['crl']['b_pure']))
  for new,original in [('losing','losing'),('losing_month','losing_this_month'),('burn20','burn20'),('burn50','burn50'),('burn80','burn80'),('burn90','burn90'),('trading','trading'),('trades','trades')]:
   assert r[new]==c['crl'][original],(key(r),new,r[new],c['crl'][original])
assert err<1e-6 and delta_err<1e-6,(err,delta_err)
numeric=[k for k,v in rows[0].items() if isinstance(v,(int,float)) and k not in ['month','min_trigger_net_usd','min_trigger_net_bp']]
monthly=[]; final=[]
for case in cases:
 for m in range(1,25):
  rr=[r for r in rows if r['case']==case['id'] and r['month']==m]; assert len(rr)==18
  a=dict(case=case['id'],month=m,**{k:st.mean(r[k] for r in rr) for k in numeric})
  a.update(client_better_pairs=sum(r['client_delta_std']>0 for r in rr),broker_better_pairs=sum(r['broker_delta_std']>0 for r in rr),broker_better_and_less_burn50_pairs=sum(r['broker_delta_std']>0 and r['burn50']<r['std_burn50'] for r in rr),joint_better_pairs=sum(r['client_delta_std']>0 and r['broker_delta_std']>0 for r in rr),broker_positive_pairs=sum(r['broker_cumulative']>0 for r in rr),min_client_delta_std=min(r['client_delta_std'] for r in rr),max_client_delta_std=max(r['client_delta_std'] for r in rr),min_broker_delta_std=min(r['broker_delta_std'] for r in rr),max_broker_delta_std=max(r['broker_delta_std'] for r in rr))
  monthly.append(a)
  if m==24:
   allr=[r for r in rows if r['case']==case['id']]
   final.append(dict(a,kind=case['kind'],value=case['value'],min_potential_trigger_net_bp=case['min_potential_trigger_net_bp'],total_trades=sum(r['trades'] for r in allr),trades_delta_base=sum(r['trades']-r['base_trades'] for r in allr)))
hashchecks=[]
for f,h in read(P/'source_hashes.json').items():
 path=R/f if (R/f).is_file() else P/f
 assert hashlib.sha256(path.read_bytes()).hexdigest()==h,str(path)
 hashchecks.append(f)
checks=dict(status='PASS',runs=len(cases)*18,monthly_rows=len(rows),initial_clients_per_run=1000,client_paths=len(cases)*18000,client_months=len(rows)*1000,correlated_replays_not_independent_observations=True,baseline_monthly_max_error=err,conservation_delta_max_error=delta_err,source_hashes_verified=len(hashchecks),per_window=runchecks,independent_review_of_new_experiment=False)
summary=dict(purpose='Client premium surcharge, trigger and 5x unchanged, pure B-book',unit='USD per initial client, mean across all 18 variants; wealth initial USD50000',scope='Historical sensitivity, not a price recommendation or empirical retention model',cases=final,rejected=[c for c in ad['cases'] if not c['admissible']],monthly=monthly,checks=checks)
for name,value in [('summary.json',summary),('checks.json',checks),('monthly_detail.json',rows)]:
 (P/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf8')
with (P/'monthly_detail.csv').open('w',encoding='utf-8-sig',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
lines=['PREMIUM MAGGIORATO, TRIGGER FERMO, LEVA 5X — B-BOOK PURO','Importi medi per cliente iniziale, 24 mesi, tutte le 18 varianti.','Tariffa | patrimonio cliente | margine B-book | delta cliente vs STD | delta broker vs STD | coppie cliente/broker/entrambi superiori']
for r in final:
 lines.append(f"{r['case']:8s} | {r['wealth_mean']:,.2f} | {r['broker_cumulative']:,.2f} | {r['client_delta_std']:+,.2f} | {r['broker_delta_std']:+,.2f} | {r['client_better_pairs']}/{r['broker_better_pairs']}/{r['joint_better_pairs']}")
lines+=['','Base di confronto tradizionale: patrimonio '+str(final[0]['std_wealth'])+'; margine broker '+str(final[0]['std_broker']), 'q5 = premio Q aumentato del 5% (100 diventa 105), NON 5% del capitale.', 'bp0.5 = 0,5 punti base sul capitale a ogni apertura, oltre al premio Q.', 'Ogni tariffa si applica a tutte le aperture CRL, anche senza attivazione.','Le maggiorazioni sono trattenute dal broker. Tutti gli altri costi e il tradizionale restano invariati.', 'Ricostruiti capitale, esiti giornalieri e rientri: non è una somma a operazioni fisse.', 'Le date/uscite dei contratti sono riusate dopo verifica della regola di durata; i percorsi dei conti vengono ricalcolati.', 'Contabilità: patrimonio cliente + margine B-book + costi inclusi = capitale iniziale.','Tutti i trigger storici ammissibili hanno netto positivo. Il controllo sul campione non garantisce prezzi futuri.', 'Nessuna maggiorazione può essere presentata come beneficio gratuito per il cliente.', 'Il numero di clienti in perdita, la gravità e il capitale medio sono KPI diversi.', 'Churn volontario disattivato; non si stima la retention commerciale.','Le varianti condividono dati/seed: non sono osservazioni indipendenti.', 'La verifica indipendente riguarda il riferimento originale. Questa estensione ha controlli interni e replay esatto della base.', 'Griglie e addendum fissati prima dei nuovi risultati economici; casi rifiutati conservati.', 'Rifiutati: '+', '.join(c['id'] for c in summary['rejected']), '',json.dumps(checks,ensure_ascii=False)]
(P/'RISULTATI.txt').write_text('\n'.join(lines),encoding='utf8')
print('\n'.join(lines[:len(final)+5]));print(json.dumps(checks))
