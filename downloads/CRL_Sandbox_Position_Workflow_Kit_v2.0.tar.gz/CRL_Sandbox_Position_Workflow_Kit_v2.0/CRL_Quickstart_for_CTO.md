# CRL Conditional Retro-Leverage — Sandbox Quickstart

**For:** CTO / integration engineers at broker counterparties
**Time required:** 10–15 minutes
**Prerequisites:** Postman Desktop v10.0+, sandbox credentials from CRL Technologies

---

## What CRL Is

CRL is a deterministic pricing and lifecycle layer. It calculates position payoffs with conditional retroactive leverage and manages position state through a standard REST API. It integrates alongside your existing OMS, bridge, and risk engine without replacing them.

---

## What This Test Demonstrates

You will open a position, send a price update that crosses the trigger, and observe CRL apply leverage retroactively from the entry price — not from the trigger level. This is the core mechanic. If this works, your integration path is valid.

---

## Setup — 3 Steps

**Step 1 — Import in Postman**

Import both files from the kit:
- `CRL_Sandbox_Position_Workflow_Kit_v2.0.postman_collection.json`
- `CRL_Sandbox_Position_Workflow.postman_environment.json`

Select `CRL Sandbox — Position Workflow` from the environment dropdown.

**Step 2 — Insert credentials**

Open the environment and set:

| Variable | Value |
|---|---|
| `api_key_id` | Provided by CRL Technologies |
| `api_secret` | Provided by CRL Technologies |

`base_url` is pre-configured. HMAC signing is automatic — no manual header setup required.

**Step 3 — Run Health Check**

Execute `01 - Health`. Expected: `HTTP 200`, `status: "ok"`.
If this fails, verify network access to `crl-api.crl-technologies.com` before proceeding.

---

## The Fastest Path — 3 Requests

Execute in order:

| Request | Expected state | Expected pnl |
|---|---|---|
| `02 - LONG ITM - Open` | `INITIAL` | — |
| `03 - LONG ITM - Calc (Triggered)` | `LEVERAGED` | `50.0` |
| `04 - LONG ITM - Close` | `CLOSED` | `50.0` |

All three requests should show green checkmarks in the Test Results tab.

**What you are observing:**

The position opens at S0 = 100. The trigger is set at K = 105. When the price reaches ST = 110, CRL activates 5x leverage retroactively from S0 — not from K.
```
CRL payoff      = 5 x (110 - 100) = 50   <- retroactive from entry
Non-retroactive = 5 x (110 - 105) = 25   <- from trigger only
```

The difference between 50 and 25 is the structural value of CRL retroactivity.

---

## If the Test Passes

You have verified API connectivity, HMAC authentication, and the full position lifecycle. The engine is live and deterministic.

Next step: contact CRL Technologies to schedule a technical integration review.

**support@crl-technologies.com**

---

## If Something Fails

| Symptom | Action |
|---|---|
| `HTTP 401 AUTH_MISSING` | Check all three headers present — the pre-request script handles this automatically |
| `HTTP 401 AUTH_FAILED` | Verify `api_secret` in environment — no extra spaces |
| `HTTP 401 AUTH_EXPIRED` | Verify system clock is accurate (NTP) |
| `HTTP 404 POSITION_NOT_FOUND` | Run Open before Calc — position_id is set automatically |
| No trigger on Calc | Verify `current_price` > `strike` for LONG positions |

---

*CRL Technologies, Inc. — For MiFID II Professional Clients and Eligible Counterparties only — Sandbox environment — Not for production use*
