SANDBOX ONLY — NOT FOR PRODUCTION USE

---

# CRL Sandbox — Position Workflow Kit v2.0

**CRL Conditional Retro-Leverage**
Controlled broker evaluation kit (professional and eligible counterparty evaluation only).

---

## What this sandbox demonstrates

- Full CRL lifecycle: open → calc → trigger → close
- Trigger activation and retroactive leverage
- Deterministic P&L behaviour through the broker-style API workflow
- Symmetric behaviour for LONG and SHORT positions

## Who this is for

- CTO / integration engineers
- Risk and dealing desks
- Technical evaluators at broker counterparties

## Not intended for

- Retail users
- Production deployment
- End-client distribution

---

## Fastest path (recommended)

1. Run `01 - Health`
2. Run `02 - LONG ITM - Open`
3. Run `03 - LONG ITM - Calc (Triggered)`
4. Run `04 - LONG ITM - Close`

**Expected result:**

| Step | Expected state | Expected pnl |
|---|---|---|
| Open | INITIAL | — |
| Calc (Triggered) | LEVERAGED | 40.0 |
| Close | CLOSED | 40.0 |

- `trigger_event.triggered` = true
- `retro_jump` > 0 when trigger fires
- close pnl = 5 × (110 − 100) − 10 = **40.0**

---

## What CRL Is

CRL operates as a **deterministic pricing and lifecycle layer**. It calculates payoffs and manages position state. It does not execute trades, hold funds, or intermediate client relationships. It integrates alongside existing broker execution engines — OMS, bridge, risk engine — without replacing them.

---

## The Retroactivity Proof

For a LONG position with trigger hit:

```
pnl = L × (ST - S0) - premium     ← CRL retroactive (correct)
pnl = L × (ST - K)  - premium     ← non-retroactive (what CRL is not)
```

**Concrete example — LONG ITM:**

| Parameter | Value |
|-----------|-------|
| S0 (entry price) | 100.0 |
| K (strike / trigger) | 105.0 |
| ST (current price) | 110.0 |
| L (leverage) | 5 |
| premium | 10.0 |

```
CRL retroactive pnl  = 5 × (110 - 100) - 10 = 40   ✓
Non-retroactive pnl  = 5 × (110 - 105) - 10 = 15   ✗
```

---

## API Flow — 3 Steps

```
POST /api/v1/positions              →  state: INITIAL
POST /v1/calc                       →  state: LEVERAGED (trigger hit) | INITIAL (not hit)
POST /api/v1/positions/{id}/close   →  state: CLOSED
```

---

## All Scenarios

| Scenario | S0 | K | ST | Expected state | Expected pnl |
|---|---|---|---|---|---|
| LONG ITM | 100 | 105 | 110 | LEVERAGED | **40.0** |
| LONG OTM | 100 | 105 | 103 | INITIAL | 3.0 |
| SHORT ITM | 100 | 95 | 90 | LEVERAGED | **40.0** |
| SHORT OTM | 100 | 95 | 97 | INITIAL | −3.0 |

---

## Authentication — HMAC-SHA256

```
canonical_string = METHOD + "\n" + PATH + "\n" + TIMESTAMP + "\n" + BODY_HASH
signature        = base64(HMAC-SHA256(canonical_string, api_secret))
```

Headers required on every signed request:

| Header | Value |
|--------|-------|
| `X-API-Key` | Your key ID |
| `X-CRL-Timestamp` | Unix timestamp (seconds) |
| `X-CRL-Signature` | HMAC signature (base64) |

Timestamp window: ±300 seconds.

> **Note on canonical path:** the path used for signing must match the request path exactly and must not include the query string. Example: sign `/api/v1/positions`, not `/api/v1/positions?limit=1`.

The Postman collection includes a pre-request script that generates all HMAC headers automatically.

---

## Credentials

Sandbox credentials are not included in this kit.
They are issued separately by CRL Technologies.

```
api_key_id  :  [provided by CRL Technologies]
api_secret  :  [provided by CRL Technologies]
base_url    :  https://crl-api.crl-technologies.com
```

To request sandbox credentials or technical onboarding:
**support@crl-technologies.com**

---

## Common Issues

| Error | Cause | Action |
|---|---|---|
| `AUTH_MISSING` | One or more required headers absent | Check all three headers are present |
| `AUTH_FAILED` | Wrong secret, wrong canonical path, or signature mismatch | Verify secret and that path excludes query string |
| `AUTH_EXPIRED` | Local clock drift exceeds ±300s | Verify NTP sync on signing host |
| `POSITION_NOT_FOUND` | position_id missing, incorrect, or wrong tenant | Run Open first; check environment variable |
| `404` on second close | Expected — close is not idempotent | No action required |
| No trigger activation | current_price did not cross strike | Verify price > strike for LONG, price < strike for SHORT |

---

## Kit Contents

| File | Description |
|------|-------------|
| `CRL_Sandbox_Position_Workflow_Kit_v2.0.postman_collection.json` | 13 requests — 4 scenarios × 3 steps + health, HMAC pre-request included |
| `CRL_Sandbox_Position_Workflow.postman_environment.json` | Environment template — insert credentials before use |
| `START_HERE.txt` | Fastest path guide — start here |
| `QUICK_START.txt` | Full setup guide |
| `README.md` | This document |

---

## Next Steps

After validating this collection:

1. Technical review with CRL integration team
2. Compliance verification for production onboarding
3. Production credentials provisioning
4. Integration planning with your OMS / bridge

**Technical support:** support@crl-technologies.com

---

*CRL Technologies, Inc. | SANDBOX ONLY — NOT FOR PRODUCTION USE | v2.0.0 | March 2026*
