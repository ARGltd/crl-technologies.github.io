# CRL Stateless Demo Kit — Calculation Reference

> ⚠️ STATELESS DEMO — NOT FOR PRODUCTION BROKER ONBOARDING
>
> This kit demonstrates the stateless `/v1/calc` endpoint only.
> Each request passes all parameters directly (S0, ST, K, L, premium, side) with no persistent position state.
>
> This kit does NOT implement the position-based workflow:
> `POST /api/v1/positions` → `POST /v1/calc` (with `position_id`) → `POST /api/v1/positions/{id}/close`
>
> The position-based workflow is the canonical production integration path for CRL brokers.
> For production broker onboarding, use the **CRL Sandbox v2.0 Kit** (position-based workflow).

**Version:** 1.0
**Date:** 19 March 2026 — reclassified 20 March 2026
**For:** MiFID II Professional Clients and Eligible Counterparties only

---

## Purpose

This kit verifies connectivity and HMAC authentication using four synthetic calculation scenarios
(LONG ITM, LONG OTM, SHORT ITM, SHORT OTM). It is useful for:

- testing API credentials before full onboarding
- verifying CRL payoff logic in isolation
- understanding the stateless calculation model

It is not a substitute for the Sandbox Kit and does not demonstrate persistent position lifecycle.

---

## Files in this kit

| File | Purpose |
|------|---------|
| `CRL_Broker_Kit_v1.0.postman_collection.json` | 5 requests with automatic HMAC auth |
| `CRL_Broker_Kit.postman_environment.json` | Environment — set your credentials here |

---

## Setup (3 steps)

### Step 1 — Import in Postman
Import both files: collection + environment.

### Step 2 — Set credentials
Open the **CRL Broker Kit** environment and set:

| Variable | Value |
|----------|-------|
| `api_key_id` | Your Key ID (provided by CRL Technologies) |
| `api_secret` | Your Secret (provided by CRL Technologies) |

Do not modify `base_url` or `canonical_path_calc`.

### Step 3 — Run Health Check
Send the **Health Check** request first.
Expected response: `HTTP 200`

Then send any calculation request.
Expected on first run with valid credentials: `HTTP 200` or `HTTP 422` (not `HTTP 401`).
A `401` response means credentials are incorrect or not set.

---

## Authentication

Authentication is fully automatic. The pre-request script:
1. reads `api_key_id` and `api_secret` from the environment
2. computes `BASE64(SHA256(body))` as body hash
3. builds the canonical string: `METHOD\nPATH\nTIMESTAMP\nBODY_HASH`
4. signs it: `BASE64(HMAC-SHA256(canonical, api_secret))`
5. sets headers: `X-API-Key`, `X-CRL-Timestamp`, `X-CRL-Signature`

---

## Requests included

| Request | Method | Endpoint | Description |
|---------|--------|----------|-------------|
| Health Check | GET | `/health` | Verify connectivity |
| CRL Base LONG – ITM | POST | `/v1/calc` | Long, trigger reached — stateless |
| CRL Base LONG – OTM | POST | `/v1/calc` | Long, trigger not reached — stateless |
| CRL Base SHORT – ITM | POST | `/v1/calc` | Short, trigger reached — stateless |
| CRL Base SHORT – OTM | POST | `/v1/calc` | Short, trigger not reached — stateless |

---

## Support

integration@crl-technologies.com
