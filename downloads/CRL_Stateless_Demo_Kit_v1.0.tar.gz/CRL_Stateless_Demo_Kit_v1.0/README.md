SANDBOX ONLY — NOT FOR PRODUCTION USE

---

# CRL Stateless Demo Kit v1.0

**CRL Conditional Retro-Leverage**
Stateless calculation demo for credential verification and payoff validation.

---

## What this kit validates

- HMAC-SHA256 authentication
- `/v1/calc` access
- CRL payoff logic in isolated stateless mode

## What this kit does NOT do

- Open positions
- Close positions
- Simulate the broker lifecycle
- Replace the Sandbox Position Workflow Kit

---

## When to use this kit

**Use this kit if:**
- You want to verify credentials quickly
- You want to validate CRL payoff examples in isolation
- You want to confirm HMAC signing works before the full workflow

**Do not use this kit if:**
- You want to test broker onboarding
- You want to test the open → calc → close lifecycle

For the full position workflow, use:
**CRL Sandbox Position Workflow Kit v2.0**

---

## Setup (3 steps)

### Step 1 — Import in Postman
Import both files:
- `CRL_Stateless_Demo.postman_collection.json`
- `CRL_Stateless_Demo.postman_environment.json`

### Step 2 — Set credentials
Open the **CRL Stateless Demo** environment and set:

| Variable | Value |
|----------|-------|
| `api_key_id` | Provided by CRL Technologies |
| `api_secret` | Provided by CRL Technologies |

### Step 3 — Run Health Check
Send the **Health Check** request first.
Expected response: `HTTP 200`

Then send any calculation request.
Expected with valid credentials: authentication passes. Depending on payload validity, the response will typically be HTTP 200 or HTTP 422. A 401 indicates authentication failure.

---

## Authentication

Authentication is fully automatic. The pre-request script:
1. Reads `api_key_id` and `api_secret` from the environment
2. Computes `BASE64(SHA256(body))` as body hash
3. Builds the canonical string: `METHOD\nPATH\nTIMESTAMP\nBODY_HASH`
4. Signs it: `BASE64(HMAC-SHA256(canonical, api_secret))`
5. Sets headers: `X-API-Key`, `X-CRL-Timestamp`, `X-CRL-Signature`

> **Note on canonical path:** the path must not include the query string. Sign `/v1/calc`, not `/v1/calc?param=value`.

---

## Requests included

| Request | Method | Endpoint | Description |
|---------|--------|----------|-------------|
| Health Check | GET | `/healthz` | Verify connectivity |
| CRL Base LONG – ITM | POST | `/v1/calc` | Long, trigger reached — stateless |
| CRL Base LONG – OTM | POST | `/v1/calc` | Long, trigger not reached — stateless |
| CRL Base SHORT – ITM | POST | `/v1/calc` | Short, trigger reached — stateless |
| CRL Base SHORT – OTM | POST | `/v1/calc` | Short, trigger not reached — stateless |

---

## Support

support@crl-technologies.com

---

*CRL Technologies, Inc. | SANDBOX ONLY — NOT FOR PRODUCTION USE | v1.0 | March 2026*
