# CRL Sandbox – CRL Base v1.0

**Postman Collection per validazione tecnica CRL Base**

---

## ⚠️ SCOPE & DISCLAIMER

**Target Audience**: This validation kit is intended **EXCLUSIVELY** for:
- Professional counterparties (MiFID II Eligible Contract Participants)
- Regulated financial institutions
- Licensed broker-dealers

**Purpose**: This is a **SANDBOX PRICING ENVIRONMENT** for CRL Base product validation and technical integration testing.

**Not Suitable For**:
- ❌ Retail clients
- ❌ Live trading or production use
- ❌ Non-professional investors

**Compliance**: For production deployment, separate onboarding procedures, compliance verification, and regulatory approval are required.

---

## 📦 Contenuto del Kit

- `CRL_Sandbox_CRL_Base_v1.0.postman_collection.json` - Collection con 5 request
- `CRL_SANDBOX.postman_environment.json` - Environment template
- `CRL_Base_v1.0_README.md` - Questa guida

---

## 🎯 Obiettivo

Questa collection dimostra il funzionamento del prodotto **CRL Base** in scenari realistici:
- **LONG ITM**: Trigger breach con leverage retroattivo
- **LONG OTM**: No trigger, esposizione lineare
- **SHORT ITM**: Trigger breach su movimento ribassista
- **SHORT OTM**: No trigger, esposizione lineare

Ogni scenario include:
- ✅ Parametri realistici (S0, ST, K, L, premium)
- ✅ Spiegazione del payoff teorico
- ✅ Test automatici per validazione
- ✅ Autenticazione HMAC-SHA256 automatica

---

## 🚀 Quick Start

### 1. Import in Postman

1. Apri Postman Desktop (v10.0+)
2. Click **Import**
3. Seleziona `CRL_Sandbox_CRL_Base_v1.0.postman_collection.json`
4. Seleziona `CRL_SANDBOX.postman_environment.json`

### 2. Configura Environment

Nel dropdown environment, seleziona **CRL_SANDBOX** e configura:
```
base_url: https://crl-api.crl-technologies.com
api_key_id: <YOUR_KEY_ID>
api_secret: <YOUR_SECRET>
canonical_path_calc: /v1/calc
hmac_window: 300
```

⚠️ **IMPORTANTE**: Richiedi le credenziali sandbox a support@crl-technologies.com

### 3. Test Connessione

Esegui la request **Health Check** per verificare:
- ✅ Network connectivity
- ✅ API endpoint raggiungibile
- ✅ Response time < 100ms

### 4. Esegui Scenari CRL

Esegui in sequenza le 4 request `/v1/calc`:

1. **LONG ITM**: Verifica leverage retroattivo
2. **LONG OTM**: Verifica comportamento lineare
3. **SHORT ITM**: Verifica simmetria short
4. **SHORT OTM**: Verifica protezione downside

---

## 📋 API Reference: /v1/calc Endpoint

### Request Body Parameters

| Parameter | Type | Required | Range/Values | Default | Description |
|-----------|------|----------|--------------|---------|-------------|
| `mode` | string | No | `"crl"`, `"acrl"` | `"crl"` | Calculation mode |
| `S0` | number | **Yes** | > 0 | - | Initial underlying price |
| `ST` | number | **Yes** | > 0 | - | Terminal underlying price |
| `K` | number | **Yes** | > 0 | - | Strike price for trigger |
| `L` | number | **Yes** | 2 to 10 | - | Leverage multiplier |
| `premium` | number | **Yes** | ≥ 0 | - | Premium paid for CRL certificate |
| `side` | string | No | `"long"`, `"short"` | `"long"` | Position direction |

**Validation Rules**:
- All prices (`S0`, `ST`, `K`) must be positive numbers
- Leverage `L` must be between 2 and 10 (inclusive)
- `side` is case-sensitive: use lowercase `"long"` or `"short"`
- `mode` defaults to `"crl"` if omitted

### Response Format

**Success (HTTP 200)**:
```json
{
  "pnl": -100.0,
  "gross_pnl": 50.0,
  "state": "LEVERAGED",
  "roi": -66.67,
  "exposure": 50.0,
  "trigger_crossed": true,
  "calc_time_ms": 0.234
}
```

**Response Fields**:

| Field | Type | Description |
|-------|------|-------------|
| `pnl` | number | Net profit/loss after premium deduction |
| `gross_pnl` | number | Gross PnL before premium |
| `state` | string | `"INITIAL"` (not triggered) or `"LEVERAGED"` (triggered) |
| `roi` | number | Return on investment as percentage |
| `exposure` | number | Total exposure amount |
| `trigger_crossed` | boolean | `true` if strike was breached, `false` otherwise |
| `calc_time_ms` | number | Calculation time in milliseconds |

---

## 🔐 Autenticazione HMAC-SHA256

### Come Funziona

La collection include uno **script pre-request** che firma automaticamente ogni richiesta:
```
Canonical String = METHOD + "\n" + PATH + "\n" + TIMESTAMP + "\n" + BODY_HASH
Signature = HMAC-SHA256(Canonical String, api_secret)
```

### Headers Generati

Ogni request include automaticamente:
- `X-API-Key`: Tuo key ID
- `X-CRL-Timestamp`: Unix timestamp
- `X-CRL-Signature`: HMAC signature (hex)
- `X-Content-SHA256`: Body hash (base64)

### Debug

Apri la **Postman Console** (View → Show Postman Console) per vedere:
- Canonical string costruita
- Body hash calcolato
- Signature generata
- Headers inviati al server

---

## ⚠️ Error Handling

### Common Error Codes

| HTTP Code | Error Code | Description | Solution |
|-----------|------------|-------------|----------|
| 400 | `INVALID_REQUEST` | Missing or invalid parameters in request body | Check all required fields and data types |
| 400 | `OUT_OF_RANGE` | Parameter value outside allowed range (e.g., L > 10) | Verify parameter constraints in API Reference |
| 401 | `AUTH_FAILED` | HMAC signature verification failed | Check api_key_id, api_secret, and timestamp |
| 401 | `TIMESTAMP_OUT_OF_WINDOW` | Request timestamp too far from server time | Sync system clock (±300s tolerance) |
| 429 | `RATE_LIMIT_EXCEEDED` | Too many requests in time window | Wait and retry; check X-RateLimit-Reset header |
| 500 | `INTERNAL_ERROR` | Server-side calculation error | Contact support with X-Correlation-Id |

### Error Response Format
```json
{
  "error": {
    "code": "INVALID_REQUEST",
    "message": "Invalid request parameters: L must be between 2 and 10"
  }
}
```

---

## 🔬 Scenari Dettagliati

[... resto del README esistente ...]

---

## 📞 Supporto

**Technical Support**: support@crl-technologies.com  
**Integration Team**: integrations@crl-technologies.com  
**Documentation**: (Coming soon)

**Production Onboarding**: Contact support@crl-technologies.com for compliance procedures and production credentials.

---

## 📝 Next Steps

Dopo aver validato questa collection:

1. ✅ Discussione tecnica con team CRL
2. ✅ Compliance verification and regulatory approval
3. ✅ Configurazione ambiente production
4. ✅ Test di integrazione con sistema broker
5. ✅ Setup webhook notifications (if applicable)
6. ✅ Deployment in staging

---

## 📄 Version History

- **v1.0.0** (2025-11-19): Initial release
  - 5 core requests (health + 4 CRL scenarios)
  - HMAC-SHA256 authentication
  - Automated test assertions
  - Complete scenario documentation
  - Professional counterparties only
