# Security Notice

## Kit Contents

This package contains:
- Postman collection for CRL Base v1.0 API validation
- Postman environment template
- Quick start guide and documentation

## What This Kit Does NOT Contain

- **No credentials**: This kit ships with placeholder values only (`YOUR_API_KEY_ID_HERE` / `YOUR_API_SECRET_HERE`)
- **No active keys**: You must request your own credentials to use this kit
- **No real data**: No PII, tenant data, or production configuration

## Credentials in This Kit

The Postman environment file contains **placeholder values** that must be replaced with your own credentials:

```
api_key_id:  YOUR_API_KEY_ID_HERE
api_secret:  YOUR_API_SECRET_HERE
```

These placeholders:
- Are **not valid** against any CRL endpoint
- Will return `401 Unauthorized` if used as-is
- Must be replaced with credentials issued to your institution

## How to Obtain Real Credentials

Production and sandbox tenant credentials are:
- Issued **only** after institutional onboarding under NDA
- Delivered via **out-of-band channels** (secure email, key exchange)
- **Never shipped** inside this kit or any public documentation

To request credentials, contact: support@crl-technologies.com

## Credential Storage Requirements

Once you receive your credentials:
- Store them in your own **secret store or KMS** (AWS Secrets Manager, HashiCorp Vault, etc.)
- **Never hardcode** credentials in application code or commit to version control
- **Never share** credentials via unencrypted channels

## Safe Distribution

This kit is safe to distribute internally to your technical, security, and compliance teams because it contains no active credentials—only placeholder values that require replacement.

For questions about credential management, contact: support@crl-technologies.com
