> **Quick onboarding note**
> If you want to make a first authenticated call in under 5 minutes,
> use the **CRL Broker Kit** (provided separately) before this collection.
> This extended kit covers all 4 CRL Base scenarios in detail and is intended
> for deeper technical validation after the initial onboarding call.

---

# CRL Sandbox v2.0 — Validation Kit

**CRL Conditional Retro-Leverage**  
Sandbox validation kit for professional counterparties (MiFID II ECP).

---

## What CRL Is

CRL operates as a **deterministic pricing and lifecycle layer**. It calculates payoffs and manages position state. It does not execute trades, hold funds, or intermediate client relationships. It integrates alongside existing broker execution engines — OMS, bridge, risk engine — without replacing them.

---

## Why This Matters for Brokers

- **Reduces margin shock.** Leverage activates only after the trigger level is reached, eliminating the risk of immediate forced liquidation from entry.
- **Preserves trader upside after trigger.** Once triggered, leverage applies retroactively from the entry price — not from the trigger — so the trader captures the full move.
- **Predictable leverage activation logic.** The trigger level defines a clear, auditable activation point. The broker knows exactly when and how leverage enters the position.

---

## The Retroactivity Proof

This is the core property of CRL.

For a LONG position with trigger hit:

```
pnl = L × (ST - S0)               ← CRL retroactive (correct)
pnl = L × (ST - K)                ← non-retroactive (what CRL is not)
```

**Concrete example — LONG ITM:**

| Parameter | Value |
|-----------|-------|
| S0 (entry price) | 100.0 |
| K (strike / trigger) | 105.0 |
| ST (current price) | 110.0 |
| L (leverage) | 5 |
| premium | 10.0 |

```
CRL retroactive pnl  = 5 × (110 - 100) = 50   ✓
Non-retroactive pnl  = 5 × (110 - 105) = 25   ✗
```

The difference (50 vs 25) is the retroactive advantage: leverage activates from S0, not from K.

---

## API Flow — 3 Steps

Every CRL position follows this lifecycle:

```
POST /api/v1/positions              →  state: INITIAL
POST /v1/calc                       →  state: LEVERAGED (trigger hit) | INITIAL (not hit)
POST /api/v1/positions/{id}/close   →  state: CLOSED
```

### Step 1 — Open Position

```http
POST /api/v1/positions
Content-Type: application/json
X-API-Key: {api_key_id}
X-CRL-Timestamp: {unix_timestamp}
X-CRL-Signature: {hmac_sha256_base64}
X-Content-SHA256: {body_sha256_base64}

{
  "symbol": "EURUSD",
  "position_type": "long",
  "quantity": 1,
  "entry_price": 100.0,
  "strike": 105.0,
  "leverage": 5,
  "premium": 10.0
}
```

Response: `position_id`, `state: INITIAL`

### Step 2 — Calculate PnL

```http
POST /v1/calc
{authentication headers}

{
  "position_id": "{position_id from Step 1}",
  "current_price": 110.0
}
```

Response: `state`, `current_pnl`, `trigger_event.triggered`, `trigger_event.retro_jump`

### Step 3 — Close Position

```http
POST /api/v1/positions/{position_id}/close
{authentication headers}

{
  "exit_price": 110.0
}
```

Response: `state: CLOSED`, `pnl`

---

## Scenarios and Expected Results

All scenarios verified on production, 18 March 2026.

| Scenario | S0 | K | ST | Expected state | Expected pnl |
|---|---|---|---|---|---|
| LONG ITM | 100 | 105 | 110 | LEVERAGED | **50.0** |
| LONG OTM | 100 | 105 | 103 | INITIAL | 3.0 (linear) |
| SHORT ITM | 100 | 95 | 90 | LEVERAGED | **50.0** |
| SHORT OTM | 100 | 95 | 97 | INITIAL | -3.0 (linear) |

**ITM scenarios:** trigger fires, retroactive leverage activates, `retro_jump` is non-zero.  
**OTM scenarios:** trigger does not fire, position remains INITIAL, pnl is linear (ST - S0), premium not charged.

---

## Authentication — HMAC-SHA256

Every request requires HMAC-SHA256 authentication.

```
canonical_string = METHOD + "\n" + PATH + "\n" + TIMESTAMP + "\n" + BODY_HASH
signature        = base64(HMAC-SHA256(canonical_string, api_secret))
```

Headers required on every signed request:

| Header | Value |
|--------|-------|
| `X-API-Key` | Your key ID |
| `X-CRL-Timestamp` | Unix timestamp (seconds) |
| `X-CRL-Signature` | HMAC signature (base64) |
| `X-Content-SHA256` | SHA-256 of request body (base64) |

Timestamp window: ±300 seconds.

The Postman collection includes a pre-request script that generates all HMAC headers automatically.

---

## Sandbox Credentials

```
api_key_id  :  broker_demo_pilot_key_sandbox
api_secret  :  [provided separately — see QUICK_START.txt]
base_url    :  https://crl-api.crl-technologies.com
```

**Sandbox rate limits:**
- `/v1/calc`: 20 requests/min
- Global: 60 requests/min

To request sandbox credentials: support@crl-technologies.com

---

## Kit Contents

| File | Description |
|------|-------------|
| `CRL_Sandbox_v2.0.postman_collection.json` | 12 requests — 4 scenarios × 3 steps, HMAC pre-request script included |
| `CRL_SANDBOX_v2.0.postman_environment.json` | Environment template — insert credentials before use |
| `README.md` | This document |
| `QUICK_START.txt` | 4-step setup guide |

---

## Next Steps

After validating this collection:

1. Technical review with CRL integration team
2. Compliance verification for production onboarding
3. Production credentials provisioning
4. Integration planning with your OMS / bridge

**Integration support:** integrations@crl-technologies.com  
**Technical support:** support@crl-technologies.com

---

*CRL Technologies, Inc. | For professional counterparties only | v2.0.0 | 18 March 2026*
