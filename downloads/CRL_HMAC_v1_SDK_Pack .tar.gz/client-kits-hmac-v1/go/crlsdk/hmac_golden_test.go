package crlsdk_test

import (
	"testing"

	"github.com/crl/sdk/crlsdk"
)

// Golden Vector (DO NOT MODIFY)
const bodyJSON = `{"symbol":"BTCUSD","quantity":1,"entry_price":50000,"position_type":"long"}`
const expectedHash = "g5H/2uXLojfgT2U1F7rNUrugM40jbFBhk8wtavtYX48="
const expectedSig = "xvAP4LeGO98TlbYOsujet/65vo3HX2wfwbC9SKCUJlI="

// TestGoldenVector verifies that the Go implementation produces identical results
// to the reference golden vector. All SDK implementations must pass this test.
func TestGoldenVector(t *testing.T) {
	headers := crlsdk.SignRequest(
		"POST",
		"/api/v1/positions",
		bodyJSON,
		"test_tenant_hmac_v1_key",
		"test_secret_golden_2025",
		"1732272000",
	)

	// Verify body hash
	if headers["X-Content-SHA256"] != expectedHash {
		t.Fatalf("Body hash mismatch:\n  got:      %s\n  expected: %s",
			headers["X-Content-SHA256"], expectedHash)
	}

	// Verify signature
	if headers["X-CRL-Signature"] != expectedSig {
		t.Fatalf("Signature mismatch:\n  got:      %s\n  expected: %s",
			headers["X-CRL-Signature"], expectedSig)
	}

	// Verify all required headers present
	if headers["X-API-Key"] != "test_tenant_hmac_v1_key" {
		t.Fatal("X-API-Key header missing or incorrect")
	}
	if headers["X-CRL-Timestamp"] != "1732272000" {
		t.Fatal("X-CRL-Timestamp header missing or incorrect")
	}
	if headers["Content-Type"] != "application/json" {
		t.Fatal("Content-Type header missing or incorrect")
	}

	t.Log("✓ Golden vector test PASSED")
	t.Logf("  X-Content-SHA256: %s", headers["X-Content-SHA256"])
	t.Logf("  X-CRL-Signature:  %s", headers["X-CRL-Signature"])
}
