# Security Notice

## SDK Pack Contents

This package contains:
- HMAC v1 client implementations in Python, TypeScript, Java, C#, and Go
- Postman collection and environment templates
- Golden test vector for verifying HMAC signature calculation

## What This Pack Does NOT Contain

- **No production credentials**: All API keys and secrets in this pack are example values only
- **No active credentials**: The credentials shown cannot authenticate against any CRL endpoint
- **No real data**: No PII, tenant data, or production configuration

## Example Credentials in This Pack

The credentials referenced in README.md and test files (`test_tenant_hmac_v1_key` / `test_secret_golden_2025`) are **dummy example values**.

These credentials:
- Are **not valid** against any CRL production or sandbox endpoint
- Will return `401 Unauthorized` if used in actual API calls
- Exist solely to demonstrate HMAC signature calculation in local tests
- Should **never** be copied into production broker environments

They allow your development team to:
- Verify that your HMAC implementation matches the golden vector
- Test signature generation logic locally without network access
- Validate SDK integration before receiving real credentials

## Production and Sandbox Credentials

Real tenant credentials are:
- Issued **only** after institutional onboarding under NDA
- Delivered via **out-of-band channels** (secure email, key exchange ceremony)
- **Never shipped** inside this SDK pack or any public documentation
- Managed in your own **secret store or KMS** (AWS Secrets Manager, HashiCorp Vault, etc.)
- **Never hardcoded** in application code

## Safe Distribution

This SDK pack is safe to distribute internally to your technical, security, and compliance teams precisely because it contains no production secrets. All example credentials are inert and cannot be used to access CRL systems.

For questions about credential management, contact: security@crl-technologies.com
