using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace Crl.Sdk
{
    /// <summary>
    /// CRL HMAC v1 Signer - C# SDK
    /// 
    /// Official implementation for CRL White Label API HMAC v1 authentication.
    /// </summary>
    public static class CrlHmacSigner
    {
        /// <summary>
        /// Build HMAC v1 headers for CRL API.
        /// </summary>
        /// <param name="method">HTTP method (e.g., "POST", "GET")</param>
        /// <param name="path">API path (e.g., "/api/v1/positions")</param>
        /// <param name="bodyJson">JSON body as minified string (no extra spaces)</param>
        /// <param name="apiKey">Tenant API key identifier</param>
        /// <param name="apiSecret">HMAC signing secret (plaintext)</param>
        /// <param name="timestamp">Unix timestamp in seconds (as string)</param>
        /// <returns>Dictionary of HTTP headers including HMAC signature</returns>
        /// <example>
        /// <code>
        /// var headers = CrlHmacSigner.SignRequest(
        ///     "POST",
        ///     "/api/v1/positions",
        ///     "{\"symbol\":\"BTCUSD\",\"quantity\":1}",
        ///     "your-api-key",
        ///     "your-api-secret",
        ///     DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString()
        /// );
        /// </code>
        /// </example>
        public static IDictionary<string, string> SignRequest(
            string method,
            string path,
            string bodyJson,
            string apiKey,
            string apiSecret,
            string timestamp)
        {
            // Step 1: Calculate body hash (SHA256 -> base64)
            var bodyBytes = Encoding.UTF8.GetBytes(bodyJson);
            using var sha = SHA256.Create();
            var hashBytes = sha.ComputeHash(bodyBytes);
            var bodyHash = Convert.ToBase64String(hashBytes);

            // Step 2: Build canonical string
            // Format: METHOD\nPATH\nTIMESTAMP\nBODY_HASH
            var canonical = string.Join("\n",
                method.ToUpperInvariant(),
                path,
                timestamp,
                bodyHash
            );

            // Step 3: Calculate HMAC-SHA256 signature
            using var hmac = new HMACSHA256(Encoding.UTF8.GetBytes(apiSecret));
            var sigBytes = hmac.ComputeHash(Encoding.UTF8.GetBytes(canonical));
            var signature = Convert.ToBase64String(sigBytes);

            // Step 4: Return headers
            return new Dictionary<string, string>
            {
                ["X-API-Key"] = apiKey,
                ["X-CRL-Timestamp"] = timestamp,
                ["X-Content-SHA256"] = bodyHash,
                ["X-CRL-Signature"] = signature,
                ["Content-Type"] = "application/json"
            };
        }
    }
}
