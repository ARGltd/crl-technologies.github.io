module github.com/crl/sdk

go 1.18

// CRL HMAC v1 Signer - Official Go SDK
// No external dependencies required (uses only Go standard library)
