// Package crlsdk provides CRL HMAC v1 authentication for Go applications.
//
// Official implementation for CRL White Label API HMAC v1 authentication.
package crlsdk

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/base64"
	"strings"
)

// SignRequest builds HMAC v1 headers for CRL API.
//
// Parameters:
//   - method: HTTP method (e.g., "POST", "GET")
//   - path: API path (e.g., "/api/v1/positions")
//   - bodyJSON: JSON body as minified string (no extra spaces)
//   - apiKey: Tenant API key identifier
//   - apiSecret: HMAC signing secret (plaintext)
//   - timestamp: Unix timestamp in seconds (as string)
//
// Returns a map of HTTP headers including HMAC signature.
//
// Example:
//
//	headers := crlsdk.SignRequest(
//	    "POST",
//	    "/api/v1/positions",
//	    `{"symbol":"BTCUSD","quantity":1}`,
//	    "your-api-key",
//	    "your-api-secret",
//	    strconv.FormatInt(time.Now().Unix(), 10),
//	)
func SignRequest(method, path, bodyJSON, apiKey, apiSecret, timestamp string) map[string]string {
	// Step 1: Calculate body hash (SHA256 -> base64)
	h := sha256.New()
	h.Write([]byte(bodyJSON))
	bodyHash := base64.StdEncoding.EncodeToString(h.Sum(nil))

	// Step 2: Build canonical string
	// Format: METHOD\nPATH\nTIMESTAMP\nBODY_HASH
	canonical := strings.Join([]string{
		strings.ToUpper(method),
		path,
		timestamp,
		bodyHash,
	}, "\n")

	// Step 3: Calculate HMAC-SHA256 signature
	mac := hmac.New(sha256.New, []byte(apiSecret))
	mac.Write([]byte(canonical))
	signature := base64.StdEncoding.EncodeToString(mac.Sum(nil))

	// Step 4: Return headers
	return map[string]string{
		"X-API-Key":        apiKey,
		"X-CRL-Timestamp":  timestamp,
		"X-Content-SHA256": bodyHash,
		"X-CRL-Signature":  signature,
		"Content-Type":     "application/json",
	}
}
