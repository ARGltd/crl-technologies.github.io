"""
CRL HMAC v1 Signer - Python SDK

Official implementation for CRL White Label API HMAC v1 authentication.
"""

import hmac
import hashlib
import base64


class CrlHmacSigner:
    """
    CRL HMAC v1 request signer.
    
    Generates authentication headers for CRL API requests using HMAC-SHA256.
    """
    
    @staticmethod
    def sign_request(
        method: str,
        path: str,
        body_json: str,
        api_key: str,
        api_secret: str,
        timestamp: str
    ) -> dict:
        """
        Build HMAC v1 headers for CRL API.
        
        Args:
            method: HTTP method (e.g., "POST", "GET")
            path: API path (e.g., "/api/v1/positions")
            body_json: JSON body as minified string (no extra spaces)
            api_key: Tenant API key identifier
            api_secret: HMAC signing secret (plaintext)
            timestamp: Unix timestamp in seconds (as string)
        
        Returns:
            Dictionary of HTTP headers including HMAC signature
        
        Example:
            >>> import json, time
            >>> body = {"symbol": "BTCUSD", "quantity": 1}
            >>> headers = CrlHmacSigner.sign_request(
            ...     "POST",
            ...     "/api/v1/positions",
            ...     json.dumps(body, separators=(',', ':')),
            ...     "your-api-key",
            ...     "your-api-secret",
            ...     str(int(time.time()))
            ... )
        """
        # Step 1: Calculate body hash (SHA256 -> base64)
        body_hash = base64.b64encode(
            hashlib.sha256(body_json.encode("utf-8")).digest()
        ).decode("ascii")
        
        # Step 2: Build canonical string
        # Format: METHOD\nPATH\nTIMESTAMP\nBODY_HASH
        canonical = "\n".join([
            method.upper(),
            path,
            timestamp,
            body_hash
        ])
        
        # Step 3: Calculate HMAC-SHA256 signature
        signature = base64.b64encode(
            hmac.new(
                api_secret.encode("utf-8"),
                canonical.encode("utf-8"),
                hashlib.sha256
            ).digest()
        ).decode("ascii")
        
        # Step 4: Return headers
        return {
            "X-API-Key": api_key,
            "X-CRL-Timestamp": timestamp,
            "X-Content-SHA256": body_hash,
            "X-CRL-Signature": signature,
            "Content-Type": "application/json",
        }
