"""
Golden Vector Test for CRL HMAC v1 Python SDK

This test verifies that the Python implementation produces identical results
to the reference golden vector. All SDK implementations must pass this test.
"""

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from crl_hmac_signer import CrlHmacSigner

# Golden Vector (DO NOT MODIFY)
BODY_JSON = '{"symbol":"BTCUSD","quantity":1,"entry_price":50000,"position_type":"long"}'
EXPECTED_HASH = "g5H/2uXLojfgT2U1F7rNUrugM40jbFBhk8wtavtYX48="
EXPECTED_SIG = "xvAP4LeGO98TlbYOsujet/65vo3HX2wfwbC9SKCUJlI="


def test_golden_vector():
    """
    Test that HMAC calculation matches golden vector.
    
    This is the definitive test - if this passes, the implementation
    is compatible with all other CRL HMAC v1 SDKs.
    """
    headers = CrlHmacSigner.sign_request(
        method="POST",
        path="/api/v1/positions",
        body_json=BODY_JSON,
        api_key="test_tenant_hmac_v1_key",
        api_secret="test_secret_golden_2025",
        timestamp="1732272000"
    )
    
    # Verify body hash
    assert headers["X-Content-SHA256"] == EXPECTED_HASH, \
        f"Body hash mismatch: got {headers['X-Content-SHA256']}, expected {EXPECTED_HASH}"
    
    # Verify signature
    assert headers["X-CRL-Signature"] == EXPECTED_SIG, \
        f"Signature mismatch: got {headers['X-CRL-Signature']}, expected {EXPECTED_SIG}"
    
    # Verify all required headers present
    assert "X-API-Key" in headers
    assert "X-CRL-Timestamp" in headers
    assert "Content-Type" in headers
    
    print("✓ Golden vector test PASSED")
    print(f"  X-Content-SHA256: {headers['X-Content-SHA256']}")
    print(f"  X-CRL-Signature:  {headers['X-CRL-Signature']}")


if __name__ == "__main__":
    test_golden_vector()
