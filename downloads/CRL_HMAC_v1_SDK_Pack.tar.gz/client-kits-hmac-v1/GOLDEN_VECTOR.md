# CRL HMAC v1 Golden Vector Specification

**Version:** 1.0  
**Date:** November 22, 2025  
**Status:** FROZEN (do not modify)

---

## Purpose

This document defines the **official golden vector** for CRL HMAC v1 authentication. All SDK implementations **MUST** produce identical results for this test case to ensure 100% interoperability.

---

## Golden Vector Values

### Input Parameters

```
METHOD      = "POST"
PATH        = "/api/v1/positions"
TIMESTAMP   = "1732272000"
API_KEY     = "test_tenant_hmac_v1_key"
API_SECRET  = "test_secret_golden_2025"
```

### Request Body (JSON)

**Minified (no extra spaces):**
```json
{"symbol":"BTCUSD","quantity":1,"entry_price":50000,"position_type":"long"}
```

**CRITICAL:** 
- No spaces after colons
- No spaces after commas
- No trailing newline
- Exact character count: 73 bytes

### Expected Outputs

```
X-Content-SHA256 = "g5H/2uXLojfgT2U1F7rNUrugM40jbFBhk8wtavtYX48="
X-CRL-Signature  = "xvAP4LeGO98TlbYOsujet/65vo3HX2wfwbC9SKCUJlI="
```

---

## Calculation Steps (Reference)

### Step 1: Body Hash

```python
body_json = '{"symbol":"BTCUSD","quantity":1,"entry_price":50000,"position_type":"long"}'
body_hash = base64(sha256(body_json))
# Result: "g5H/2uXLojfgT2U1F7rNUrugM40jbFBhk8wtavtYX48="
```

### Step 2: Canonical String

```
POST
/api/v1/positions
1732272000
g5H/2uXLojfgT2U1F7rNUrugM40jbFBhk8wtavtYX48=
```

**Format:** `{METHOD}\n{PATH}\n{TIMESTAMP}\n{BODY_HASH}`

**CRITICAL:**
- Components separated by newline (`\n`)
- No leading newline
- No trailing newline
- Exactly 3 newlines total

### Step 3: HMAC Signature

```python
canonical = "POST\n/api/v1/positions\n1732272000\ng5H/2uXLojfgT2U1F7rNUrugM40jbFBhk8wtavtYX48="
secret = "test_secret_golden_2025"
signature = base64(hmac_sha256(canonical, secret))
# Result: "xvAP4LeGO98TlbYOsujet/65vo3HX2wfwbC9SKCUJlI="
```

---

## Verification Procedure

All SDKs **MUST** include a golden vector test that:

1. ✅ Uses exactly the input parameters above
2. ✅ Calculates `X-Content-SHA256`
3. ✅ Verifies result matches `g5H/2uXLojfgT2U1F7rNUrugM40jbFBhk8wtavtYX48=`
4. ✅ Calculates `X-CRL-Signature`
5. ✅ Verifies result matches `xvAP4LeGO98TlbYOsujet/65vo3HX2wfwbC9SKCUJlI=`

**Test must FAIL if either value differs by even one character.**

---

## Common Mistakes

### ❌ Wrong: Timestamp in milliseconds
```
timestamp = "1732272000000"  # WRONG!
```

### ✅ Correct: Timestamp in seconds
```
timestamp = "1732272000"
```

---

### ❌ Wrong: Pretty-printed JSON
```json
{
  "symbol": "BTCUSD",
  "quantity": 1,
  "entry_price": 50000,
  "position_type": "long"
}
```

### ✅ Correct: Minified JSON
```json
{"symbol":"BTCUSD","quantity":1,"entry_price":50000,"position_type":"long"}
```

---

### ❌ Wrong: Extra newline in canonical string
```
POST\n/api/v1/positions\n1732272000\nhash\n
                                         ^--- NO!
```

### ✅ Correct: No trailing newline
```
POST\n/api/v1/positions\n1732272000\nhash
```

---

### ❌ Wrong: Using hex encoding
```python
signature = hmac_sha256(canonical, secret).hexdigest()
# Result: "c6f00fe...78c5a49"  # HEX, WRONG!
```

### ✅ Correct: Using base64 encoding
```python
signature = base64(hmac_sha256(canonical, secret))
# Result: "xvAP4Le...SKCUJlI="  # BASE64, CORRECT!
```

---

## Binary Representations (For Debugging)

### Body JSON (UTF-8 bytes)
```
7b 22 73 79 6d 62 6f 6c 22 3a 22 42 54 43 55 53 44 22 2c 22 71 75 61 6e 74 69 74 79 22 3a 31 2c 22 65 6e 74 72 79 5f 70 72 69 63 65 22 3a 35 30 30 30 30 2c 22 70 6f 73 69 74 69 6f 6e 5f 74 79 70 65 22 3a 22 6c 6f 6e 67 22 7d
```

### SHA256 of Body (before base64)
```
83 91 ff da e5 cb a2 37 e0 4f 65 35 17 ba cd 52 bb a0 33 8d 23 6c 50 61 93 cc 2d 6a fb 58 5f 8f
```

### HMAC-SHA256 of Canonical (before base64)
```
c6 f0 0f e0 b7 86 3b df 13 95 b6 0e b2 e8 de b7 fe b9 be 8d c7 5f 6c 1f c1 b0 bd 48 a0 94 26 52
```

---

## Test Commands

### Python
```bash
cd python
pytest tests/test_golden_vector.py -v
```

### TypeScript
```bash
cd typescript
npm test
```

### Java
```bash
cd java
mvn test
```

### C#
```bash
cd csharp
dotnet test
```

### Go
```bash
cd go
go test ./crlsdk -v
```

**All tests must output:**
```
✓ Golden vector test PASSED
  X-Content-SHA256: g5H/2uXLojfgT2U1F7rNUrugM40jbFBhk8wtavtYX48=
  X-CRL-Signature:  xvAP4LeGO98TlbYOsujet/65vo3HX2wfwbC9SKCUJlI=
```

---

## Freeze Notice

**This golden vector is FROZEN as of November 22, 2025.**

Changes to this specification:
- ❌ NOT ALLOWED for v1 implementations
- ❌ Would break compatibility across all SDKs
- ❌ Would invalidate existing integrations

For new features or changes:
- Create HMAC v2 specification
- Maintain v1 compatibility indefinitely

---

## Contact

Questions about this specification:
- Technical: support@crl-technologies.com
- Security: security@crl-technologies.com

---

**If your SDK passes this test, it's compatible with all CRL systems. Period.** ✅
