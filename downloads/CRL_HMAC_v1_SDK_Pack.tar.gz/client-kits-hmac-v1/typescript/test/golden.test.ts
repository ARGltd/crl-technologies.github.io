/**
 * Golden Vector Test for CRL HMAC v1 TypeScript SDK
 * 
 * This test verifies that the TypeScript implementation produces identical results
 * to the reference golden vector. All SDK implementations must pass this test.
 */

import { CrlHmacSigner } from '../src/CrlHmacSigner';

// Golden Vector (DO NOT MODIFY)
const BODY_JSON = '{"symbol":"BTCUSD","quantity":1,"entry_price":50000,"position_type":"long"}';
const EXPECTED_HASH = 'g5H/2uXLojfgT2U1F7rNUrugM40jbFBhk8wtavtYX48=';
const EXPECTED_SIG = 'xvAP4LeGO98TlbYOsujet/65vo3HX2wfwbC9SKCUJlI=';

describe('CRL HMAC v1 Golden Vector', () => {
  test('produces correct body hash and signature', () => {
    const headers = CrlHmacSigner.signRequest(
      'POST',
      '/api/v1/positions',
      BODY_JSON,
      'test_tenant_hmac_v1_key',
      'test_secret_golden_2025',
      '1732272000'
    );

    // Verify body hash
    expect(headers['X-Content-SHA256']).toBe(EXPECTED_HASH);

    // Verify signature
    expect(headers['X-CRL-Signature']).toBe(EXPECTED_SIG);

    // Verify all required headers present
    expect(headers['X-API-Key']).toBe('test_tenant_hmac_v1_key');
    expect(headers['X-CRL-Timestamp']).toBe('1732272000');
    expect(headers['Content-Type']).toBe('application/json');

    console.log('✓ Golden vector test PASSED');
    console.log(`  X-Content-SHA256: ${headers['X-Content-SHA256']}`);
    console.log(`  X-CRL-Signature:  ${headers['X-CRL-Signature']}`);
  });
});
