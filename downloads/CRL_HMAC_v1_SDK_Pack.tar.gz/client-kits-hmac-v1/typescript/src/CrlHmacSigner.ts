/**
 * CRL HMAC v1 Signer - TypeScript/Node.js SDK
 * 
 * Official implementation for CRL White Label API HMAC v1 authentication.
 */

import crypto from 'crypto';

export interface CrlHmacHeaders {
  [key: string]: string;
}

/**
 * CRL HMAC v1 request signer.
 * 
 * Generates authentication headers for CRL API requests using HMAC-SHA256.
 */
export class CrlHmacSigner {
  /**
   * Build HMAC v1 headers for CRL API.
   * 
   * @param method - HTTP method (e.g., "POST", "GET")
   * @param path - API path (e.g., "/api/v1/positions")
   * @param bodyJson - JSON body as minified string (no extra spaces)
   * @param apiKey - Tenant API key identifier
   * @param apiSecret - HMAC signing secret (plaintext)
   * @param timestamp - Unix timestamp in seconds (as string)
   * @returns Dictionary of HTTP headers including HMAC signature
   * 
   * @example
   * ```typescript
   * const body = {symbol: "BTCUSD", quantity: 1};
   * const headers = CrlHmacSigner.signRequest(
   *   "POST",
   *   "/api/v1/positions",
   *   JSON.stringify(body),
   *   "your-api-key",
   *   "your-api-secret",
   *   Math.floor(Date.now() / 1000).toString()
   * );
   * ```
   */
  static signRequest(
    method: string,
    path: string,
    bodyJson: string,
    apiKey: string,
    apiSecret: string,
    timestamp: string
  ): CrlHmacHeaders {
    // Step 1: Calculate body hash (SHA256 -> base64)
    const bodyHash = crypto
      .createHash('sha256')
      .update(bodyJson, 'utf8')
      .digest('base64');

    // Step 2: Build canonical string
    // Format: METHOD\nPATH\nTIMESTAMP\nBODY_HASH
    const canonical = [
      method.toUpperCase(),
      path,
      timestamp,
      bodyHash
    ].join('\n');

    // Step 3: Calculate HMAC-SHA256 signature
    const signature = crypto
      .createHmac('sha256', apiSecret)
      .update(canonical, 'utf8')
      .digest('base64');

    // Step 4: Return headers
    return {
      'X-API-Key': apiKey,
      'X-CRL-Timestamp': timestamp,
      'X-Content-SHA256': bodyHash,
      'X-CRL-Signature': signature,
      'Content-Type': 'application/json',
    };
  }
}
