using Xunit;
using Crl.Sdk;

namespace Crl.Sdk.Tests
{
    /// <summary>
    /// Golden Vector Test for CRL HMAC v1 C# SDK
    /// 
    /// This test verifies that the C# implementation produces identical results
    /// to the reference golden vector. All SDK implementations must pass this test.
    /// </summary>
    public class CrlHmacSignerTests
    {
        // Golden Vector (DO NOT MODIFY)
        private const string BodyJson =
            "{\"symbol\":\"BTCUSD\",\"quantity\":1,\"entry_price\":50000,\"position_type\":\"long\"}";
        private const string ExpectedHash =
            "g5H/2uXLojfgT2U1F7rNUrugM40jbFBhk8wtavtYX48=";
        private const string ExpectedSig =
            "xvAP4LeGO98TlbYOsujet/65vo3HX2wfwbC9SKCUJlI=";

        [Fact]
        public void GoldenVector()
        {
            var headers = CrlHmacSigner.SignRequest(
                "POST",
                "/api/v1/positions",
                BodyJson,
                "test_tenant_hmac_v1_key",
                "test_secret_golden_2025",
                "1732272000"
            );

            // Verify body hash
            Assert.Equal(ExpectedHash, headers["X-Content-SHA256"]);

            // Verify signature
            Assert.Equal(ExpectedSig, headers["X-CRL-Signature"]);

            // Verify all required headers present
            Assert.Equal("test_tenant_hmac_v1_key", headers["X-API-Key"]);
            Assert.Equal("1732272000", headers["X-CRL-Timestamp"]);
            Assert.Equal("application/json", headers["Content-Type"]);

            // Output for verification
            System.Console.WriteLine("✓ Golden vector test PASSED");
            System.Console.WriteLine($"  X-Content-SHA256: {headers["X-Content-SHA256"]}");
            System.Console.WriteLine($"  X-CRL-Signature:  {headers["X-CRL-Signature"]}");
        }
    }
}
