package com.crl.sdk;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

/**
 * CRL HMAC v1 Signer - Java SDK
 * 
 * Official implementation for CRL White Label API HMAC v1 authentication.
 */
public class CrlHmacSigner {

    /**
     * Build HMAC v1 headers for CRL API.
     * 
     * @param method HTTP method (e.g., "POST", "GET")
     * @param path API path (e.g., "/api/v1/positions")
     * @param bodyJson JSON body as minified string (no extra spaces)
     * @param apiKey Tenant API key identifier
     * @param apiSecret HMAC signing secret (plaintext)
     * @param timestamp Unix timestamp in seconds (as string)
     * @return Map of HTTP headers including HMAC signature
     * @throws Exception if hashing or HMAC calculation fails
     * 
     * @example
     * <pre>{@code
     * Map<String, String> headers = CrlHmacSigner.signRequest(
     *     "POST",
     *     "/api/v1/positions",
     *     "{\"symbol\":\"BTCUSD\",\"quantity\":1}",
     *     "your-api-key",
     *     "your-api-secret",
     *     String.valueOf(System.currentTimeMillis() / 1000)
     * );
     * }</pre>
     */
    public static Map<String, String> signRequest(
            String method,
            String path,
            String bodyJson,
            String apiKey,
            String apiSecret,
            String timestamp
    ) throws Exception {
        
        // Step 1: Calculate body hash (SHA256 -> base64)
        byte[] bodyBytes = bodyJson.getBytes(StandardCharsets.UTF_8);
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hashBytes = digest.digest(bodyBytes);
        String bodyHash = Base64.getEncoder().encodeToString(hashBytes);

        // Step 2: Build canonical string
        // Format: METHOD\nPATH\nTIMESTAMP\nBODY_HASH
        String canonical = method.toUpperCase() + "\n" +
                          path + "\n" +
                          timestamp + "\n" +
                          bodyHash;

        // Step 3: Calculate HMAC-SHA256 signature
        Mac mac = Mac.getInstance("HmacSHA256");
        SecretKeySpec keySpec = new SecretKeySpec(
            apiSecret.getBytes(StandardCharsets.UTF_8),
            "HmacSHA256"
        );
        mac.init(keySpec);
        byte[] sigBytes = mac.doFinal(canonical.getBytes(StandardCharsets.UTF_8));
        String signature = Base64.getEncoder().encodeToString(sigBytes);

        // Step 4: Return headers
        Map<String, String> headers = new HashMap<>();
        headers.put("X-API-Key", apiKey);
        headers.put("X-CRL-Timestamp", timestamp);
        headers.put("X-Content-SHA256", bodyHash);
        headers.put("X-CRL-Signature", signature);
        headers.put("Content-Type", "application/json");

        return headers;
    }
}
