package com.crl.sdk;

import org.junit.jupiter.api.Test;
import java.util.Map;
import static org.junit.jupiter.api.Assertions.assertEquals;

/**
 * Golden Vector Test for CRL HMAC v1 Java SDK
 * 
 * This test verifies that the Java implementation produces identical results
 * to the reference golden vector. All SDK implementations must pass this test.
 */
public class CrlHmacSignerTest {

    // Golden Vector (DO NOT MODIFY)
    private static final String BODY_JSON =
        "{\"symbol\":\"BTCUSD\",\"quantity\":1,\"entry_price\":50000,\"position_type\":\"long\"}";
    private static final String EXPECTED_HASH =
        "g5H/2uXLojfgT2U1F7rNUrugM40jbFBhk8wtavtYX48=";
    private static final String EXPECTED_SIG =
        "xvAP4LeGO98TlbYOsujet/65vo3HX2wfwbC9SKCUJlI=";

    @Test
    public void goldenVector() throws Exception {
        Map<String, String> headers = CrlHmacSigner.signRequest(
                "POST",
                "/api/v1/positions",
                BODY_JSON,
                "test_tenant_hmac_v1_key",
                "test_secret_golden_2025",
                "1732272000"
        );

        // Verify body hash
        assertEquals(EXPECTED_HASH, headers.get("X-Content-SHA256"),
            "Body hash mismatch");

        // Verify signature
        assertEquals(EXPECTED_SIG, headers.get("X-CRL-Signature"),
            "Signature mismatch");

        // Verify all required headers present
        assertEquals("test_tenant_hmac_v1_key", headers.get("X-API-Key"));
        assertEquals("1732272000", headers.get("X-CRL-Timestamp"));
        assertEquals("application/json", headers.get("Content-Type"));

        System.out.println("✓ Golden vector test PASSED");
        System.out.println("  X-Content-SHA256: " + headers.get("X-Content-SHA256"));
        System.out.println("  X-CRL-Signature:  " + headers.get("X-CRL-Signature"));
    }
}
