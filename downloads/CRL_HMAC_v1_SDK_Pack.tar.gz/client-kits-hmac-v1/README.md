# CRL HMAC v1 SDK Pack

**Official SDK Collection for CRL White Label API HMAC v1 Authentication**

---

## Overview

This repository contains **5 official SDK implementations** for CRL HMAC v1 authentication protocol, all validated against the same **golden vector** to ensure 100% interoperability.

**Supported Languages:**
- Python 3.8+
- TypeScript/Node.js 16+
- Java 11+
- C# .NET 6.0+
- Go 1.18+

---

## Credentials & Environments

### Example Credentials in This Pack

The API credentials shown in this README and test files are **dummy example values**:

- `API Key: test_tenant_hmac_v1_key`
- `API Secret: test_secret_golden_2025`

**These credentials are NOT valid against any CRL endpoint.** If you attempt to use them in actual API calls to CRL production or sandbox environments, you will receive a `401 Unauthorized / unknown_key` response.

### Purpose of Example Credentials

These dummy values serve a specific purpose:
- They allow you to run the included **golden vector tests** locally
- They verify your HMAC signature calculation matches the expected output
- They demonstrate proper header construction and canonical string formatting

The golden vector test validates your local implementation **without requiring network access** or real credentials.

### How Production Credentials Work

Real tenant credentials are handled differently:

1. **Issuance**: Production and sandbox tenant keys are issued **only after institutional onboarding** under NDA
2. **Delivery**: Credentials are delivered via **secure out-of-band channels** (encrypted email, secure key exchange)
3. **Storage**: Your credentials must live in your own **secret store or KMS** (AWS Secrets Manager, HashiCorp Vault, Azure Key Vault, etc.)
4. **Usage**: Credentials must **never be hardcoded** in application code or committed to version control

Real tenant keys have different formats and are managed separately from this SDK pack. The example credentials in this pack cannot be confused with production credentials.

### Security Guarantee

This SDK pack contains **no production secrets** and can be safely shared with your development, security, and compliance teams for technical review.

---

## Golden Vector (Reference Standard)

All SDKs **MUST** produce identical results for this test case:

```
METHOD      = "POST"
PATH        = "/api/v1/positions"
TIMESTAMP   = "1732272000"
BODY_JSON   = {"symbol":"BTCUSD","quantity":1,"entry_price":50000,"position_type":"long"}

Expected Results:
  X-Content-SHA256 = "g5H/2uXLojfgT2U1F7rNUrugM40jbFBhk8wtavtYX48="
  X-CRL-Signature  = "xvAP4LeGO98TlbYOsujet/65vo3HX2wfwbC9SKCUJlI="
```

**Credentials (Test Tenant):**
```
API Key:    test_tenant_hmac_v1_key
API Secret: test_secret_golden_2025
```

---

## HMAC v1 Protocol Specification

### Required Headers

Every authenticated request MUST include:

```
X-API-Key:        {tenant_api_key}
X-CRL-Timestamp:  {unix_seconds}
X-Content-SHA256: {base64_sha256_of_body}
X-CRL-Signature:  {base64_hmac_sha256}
Content-Type:     application/json
```

### Canonical String Format

```
{METHOD}\n{PATH}\n{TIMESTAMP}\n{BODY_HASH}
```

**Example:**
```
POST
/api/v1/positions
1732272000
g5H/2uXLojfgT2U1F7rNUrugM40jbFBhk8wtavtYX48=
```

**CRITICAL:** Components separated by newline (`\n`), no trailing newline.

### Signature Calculation

```
1. body_hash = BASE64(SHA256(body_json))
2. canonical = METHOD + "\n" + PATH + "\n" + TIMESTAMP + "\n" + body_hash
3. signature = BASE64(HMAC-SHA256(canonical, api_secret))
```

---

## Directory Structure

```
client-kits/hmac-v1/
├── README.md                    # This file
├── SECURITY.md                  # Security notice and credentials policy
├── GOLDEN_VECTOR.md             # Golden vector specification
├── python/
│   ├── crl_hmac_signer.py      # Core implementation
│   ├── tests/
│   │   └── test_golden_vector.py
│   ├── requirements.txt
│   └── README.md
├── typescript/
│   ├── src/
│   │   └── CrlHmacSigner.ts
│   ├── test/
│   │   └── golden.test.ts
│   ├── package.json
│   ├── tsconfig.json
│   └── README.md
├── java/
│   ├── src/main/java/com/crl/sdk/
│   │   └── CrlHmacSigner.java
│   ├── src/test/java/com/crl/sdk/
│   │   └── CrlHmacSignerTest.java
│   ├── pom.xml
│   └── README.md
├── csharp/
│   ├── src/
│   │   └── CrlHmacSigner.cs
│   ├── tests/
│   │   └── CrlHmacSignerTests.cs
│   ├── CrlSdk.csproj
│   └── README.md
└── go/
    ├── crlsdk/
    │   ├── hmac.go
    │   └── hmac_golden_test.go
    ├── go.mod
    └── README.md
```

---

## Quick Start by Language

### Python

```bash
cd python
pip install -r requirements.txt
pytest tests/test_golden_vector.py -v
```

**Usage:**
```python
from crl_hmac_signer import CrlHmacSigner
import json

body = {"symbol": "BTCUSD", "quantity": 1, "entry_price": 50000, "position_type": "long"}
headers = CrlHmacSigner.sign_request(
    "POST",
    "/api/v1/positions",
    json.dumps(body, separators=(',', ':')),
    "test_tenant_hmac_v1_key",
    "test_secret_golden_2025",
    "1732272000"
)
```

### TypeScript/Node.js

```bash
cd typescript
npm install
npm test
```

**Usage:**
```typescript
import { CrlHmacSigner } from './src/CrlHmacSigner';

const headers = CrlHmacSigner.signRequest(
  'POST',
  '/api/v1/positions',
  '{"symbol":"BTCUSD","quantity":1,"entry_price":50000,"position_type":"long"}',
  'test_tenant_hmac_v1_key',
  'test_secret_golden_2025',
  '1732272000'
);
```

### Java

```bash
cd java
mvn clean test
```

**Usage:**
```java
import com.crl.sdk.CrlHmacSigner;

Map<String, String> headers = CrlHmacSigner.signRequest(
    "POST",
    "/api/v1/positions",
    "{\"symbol\":\"BTCUSD\",\"quantity\":1,\"entry_price\":50000,\"position_type\":\"long\"}",
    "test_tenant_hmac_v1_key",
    "test_secret_golden_2025",
    "1732272000"
);
```

### C# (.NET)

```bash
cd csharp
dotnet test
```

**Usage:**
```csharp
using Crl.Sdk;

var headers = CrlHmacSigner.SignRequest(
    "POST",
    "/api/v1/positions",
    "{\"symbol\":\"BTCUSD\",\"quantity\":1,\"entry_price\":50000,\"position_type\":\"long\"}",
    "test_tenant_hmac_v1_key",
    "test_secret_golden_2025",
    "1732272000"
);
```

### Go

```bash
cd go
go test ./crlsdk -v
```

**Usage:**
```go
import "example.com/crl-sdk/crlsdk"

headers := crlsdk.SignRequest(
    "POST",
    "/api/v1/positions",
    `{"symbol":"BTCUSD","quantity":1,"entry_price":50000,"position_type":"long"}`,
    "test_tenant_hmac_v1_key",
    "test_secret_golden_2025",
    "1732272000",
)
```

---

## Validation & Testing

### Golden Vector Tests

Every SDK includes a `golden vector test` that verifies:

1. ✅ Body hash calculation is correct
2. ✅ Canonical string format is correct
3. ✅ HMAC signature matches expected value

**To run all tests:**

```bash
# Python
cd python && pytest -v

# TypeScript
cd typescript && npm test

# Java
cd java && mvn test

# C#
cd csharp && dotnet test

# Go
cd go && go test ./crlsdk -v
```

**Expected output for each:**
```
✓ Golden HMAC v1 vector
  X-Content-SHA256: PASS
  X-CRL-Signature:  PASS
```

### Production Integration

After implementing your client with real credentials from CRL:

```bash
# Replace with your actual tenant credentials
API_KEY="your_actual_tenant_key"
API_SECRET="your_actual_secret"

curl -X POST https://crl-api.crl-technologies.com/v1/calc \
  -H "X-API-Key: $API_KEY" \
  -H "X-CRL-Timestamp: $(date +%s)" \
  -H "X-Content-SHA256: <calculated>" \
  -H "X-CRL-Signature: <calculated>" \
  -H "Content-Type: application/json" \
  -d '{"symbol":"BTCUSD","quantity":1,"entry_price":50000,"position_type":"long"}'

# Expected with valid credentials: 200 OK or 201 Created
# Expected with example credentials: 401 Unauthorized
```

**Note:** The example credentials in this SDK pack (`test_tenant_hmac_v1_key` / `test_secret_golden_2025`) will **not work** against production endpoints. They are for local testing only.

---

## Integration Checklist

For banks/brokers integrating with CRL API:

- [ ] Choose SDK language (or implement from scratch)
- [ ] Run golden vector test → must pass
- [ ] Generate dynamic timestamp: `Math.floor(Date.now() / 1000)`
- [ ] Minify JSON body (no extra spaces): `JSON.stringify(obj, null, 0)`
- [ ] Test against production endpoint
- [ ] Verify `201 Created` response
- [ ] Implement error handling (401, 429, 502)
- [ ] Add retry logic with exponential backoff

---

## Common Pitfalls

### ❌ Wrong: Using milliseconds for timestamp
```python
timestamp = str(int(time.time() * 1000))  # WRONG!
```

### ✅ Correct: Use seconds
```python
timestamp = str(int(time.time()))
```

---

### ❌ Wrong: Pretty-printed JSON
```json
{
  "symbol": "BTCUSD",
  "quantity": 1
}
```

### ✅ Correct: Minified JSON
```json
{"symbol":"BTCUSD","quantity":1}
```

---

### ❌ Wrong: Extra newline in canonical string
```
POST\n/api/v1/positions\n1732272000\nhash\n
                                         ^--- NO!
```

### ✅ Correct: No trailing newline
```
POST\n/api/v1/positions\n1732272000\nhash
```

---

## Troubleshooting

### Error: 401 Unauthorized "Tenant not found"

**Cause:** Incorrect API key or secret

**Fix:**
- Verify `X-API-Key` header matches tenant ID
- Verify secret used for HMAC matches server-side secret
- Check case sensitivity (keys are case-sensitive)

### Error: 401 Unauthorized "Invalid signature"

**Cause:** HMAC calculation mismatch

**Fix:**
1. Run golden vector test → must pass
2. Log canonical string client-side
3. Compare with expected format
4. Verify no extra whitespace in JSON body
5. Verify timestamp is Unix seconds (not milliseconds)

### Error: 401 Unauthorized "Timestamp expired"

**Cause:** Clock skew or old timestamp

**Fix:**
- Ensure timestamp is current: `Math.floor(Date.now() / 1000)`
- Check server time: `curl https://crl-api.crl-technologies.com/health`
- Acceptable skew: ±5 minutes

### Error: 429 Too Many Requests

**Cause:** Rate limit exceeded

**Fix:**
- Current limit: 100 req/min per tenant
- Implement exponential backoff
- Check `X-RateLimit-*` response headers

---

## SDK Maintenance

### Adding New Endpoints

To support additional endpoints (e.g., `/api/v1/orders`):

1. **Path changes only** - everything else stays the same
2. Update canonical string path component
3. Add endpoint-specific tests
4. Document endpoint-specific rate limits

**Example:**
```python
headers = CrlHmacSigner.sign_request(
    "POST",
    "/api/v1/orders",  # <--- Only this changes
    order_json,
    api_key,
    api_secret,
    timestamp
)
```

### Version Updates

HMAC v1 is **frozen** - no breaking changes allowed.

Future versions (v2, v3) will be separate implementations.

---

## Security Best Practices

### Secret Storage

**❌ Never:**
- Hardcode secrets in source code
- Commit secrets to version control
- Log secrets in plaintext
- Send secrets over unencrypted channels

**✅ Always:**
- Use environment variables or secret managers
- Rotate secrets regularly (90-day rotation recommended)
- Use different secrets for dev/staging/production
- Implement secret versioning for zero-downtime rotation

### Example (Python)
```python
import os

API_SECRET = os.environ.get('CRL_API_SECRET')
if not API_SECRET:
    raise ValueError("CRL_API_SECRET not set")
```

### TLS/SSL

All requests **MUST** use HTTPS:
- TLS 1.2 or higher
- Verify server certificate
- Do NOT disable certificate validation

---

## Support & Contact

**Technical Issues:**
- Email: support@crl-technologies.com
- Documentation: https://docs.crl-technologies.com

**Security Issues:**
- Email: support@crl-technologies.com
- PGP Key: [Available on request]

**Business Inquiries:**
- Email: andrea@crl-technologies.com

---

## License

Copyright © 2025 CRL Technologies Inc.

This SDK pack is provided to CRL API clients and partners under commercial license.

**Redistribution:**
- Allowed for internal use by licensed clients
- Not allowed for public distribution without written permission
- Modified versions must be clearly marked as unofficial

---

## Changelog

### v1.0.1 (2025-11-25)
- **Added**: SECURITY.md with comprehensive security notice
- **Added**: "Credentials & Environments" section in README
- **Clarified**: Example credentials are dummy values not valid against any endpoint
- **Updated**: Production testing section to reflect credential issuance process

### v1.0.0 (2025-11-22)
- Initial release
- 5 language SDKs (Python, TypeScript, Java, C#, Go)
- Golden vector validation
- Production tested against crl-api-production

---

**That's it. Pick your language, run the test, integrate. If golden vector passes, you're compatible.** 🚀
