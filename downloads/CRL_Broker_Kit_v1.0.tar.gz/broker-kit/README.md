# CRL Broker Kit — Integration Quick Start

**Version:** 1.0  
**Date:** 19 March 2026  
**For:** MiFID II Professional Clients and Eligible Counterparties only

---

## Files in this kit

| File | Purpose |
|------|---------|
| `CRL_Broker_Kit_v1.0.postman_collection.json` | Main collection — 5 requests with automatic HMAC auth |
| `CRL_Broker_Kit.postman_environment.json` | Environment — set your credentials here |

---

## Setup (3 steps)

### Step 1 — Import in Postman

Import both files: collection + environment.

### Step 2 — Set credentials

Open the **CRL Broker Kit** environment and set:

| Variable | Value |
|----------|-------|
| `api_key_id` | Your Key ID (provided by CRL Technologies) |
| `api_secret` | Your Secret (provided by CRL Technologies) |

Do not modify `base_url` or `canonical_path_calc`.

### Step 3 — Run Health Check

Send the **Health Check** request first.  
Expected response: `HTTP 200`

Then send any CRL Base request.  
Expected on first run with valid credentials: `HTTP 200` or `HTTP 422` (not `HTTP 401`).  
A `401` response means credentials are incorrect or not set.

---

## Authentication

Authentication is fully automatic. The pre-request script:

1. reads `api_key_id` and `api_secret` from the environment
2. computes `BASE64(SHA256(body))` as body hash
3. builds the canonical string: `METHOD\nPATH\nTIMESTAMP\nBODY_HASH`
4. signs it: `BASE64(HMAC-SHA256(canonical, api_secret))`
5. sets headers: `X-API-Key`, `X-CRL-Timestamp`, `X-CRL-Signature`

You do not need to handle authentication manually.

---

## Requests included

| Request | Method | Endpoint | Description |
|---------|--------|----------|-------------|
| Health Check | GET | `/health` | Verify connectivity |
| CRL Base LONG – ITM | POST | `/v1/calc` | Long position, trigger reached |
| CRL Base LONG – OTM | POST | `/v1/calc` | Long position, trigger not reached |
| CRL Base SHORT – ITM | POST | `/v1/calc` | Short position, trigger reached |
| CRL Base SHORT – OTM | POST | `/v1/calc` | Short position, trigger not reached |

---

## Support

integration@crl-technologies.com
